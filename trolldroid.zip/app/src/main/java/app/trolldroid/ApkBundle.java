package app.trolldroid;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.LongConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** То, что пользователь хочет установить: один APK или архив с частями (.apks / .xapk / .apkm). */
final class ApkBundle {
    /** Имя части с нативными библиотеками: config.arm64_v8a.apk, split_config.x86.apk и т.п. */
    private static final Pattern ABI = Pattern.compile("[._-](arm64_v8a|armeabi_v7a|armeabi|x86_64|x86)\\.apk$");
    /** Альтернативные варианты из bundletool (base-master_2.apk); x86_64 сюда не попадает. */
    private static final Pattern VARIANT = Pattern.compile("(?<!x86)_\\d+\\.apk$");

    final List<File> apks = new ArrayList<>();
    final List<String> permissions = new ArrayList<>();
    private File dir;

    String packageName;
    String label;
    String versionName;
    long versionCode;
    long size;
    int minSdk;
    int targetSdk;
    int obbCount;
    Drawable icon;

    /** Копирует файл в кэш, распаковывает при необходимости и читает информацию о приложении. */
    static ApkBundle load(Context context, InputStream in, LongConsumer progress) throws IOException {
        clearCache(context);
        ApkBundle bundle = new ApkBundle();
        bundle.dir = new File(workDir(context), String.valueOf(System.currentTimeMillis()));
        if (!bundle.dir.mkdirs()) throw new IOException("Не удалось создать временную папку");

        File input = new File(bundle.dir, "input");
        try (OutputStream out = new FileOutputStream(input)) {
            copy(in, out, progress);
        }

        // Тип определяем по содержимому, а не по расширению: у APK внутри есть манифест.
        List<String> names = new ArrayList<>();
        boolean single;
        try (ZipFile zip = new ZipFile(input)) {
            single = zip.getEntry("AndroidManifest.xml") != null;
            if (!single) {
                List<String> found = new ArrayList<>();
                for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements(); ) {
                    String name = e.nextElement().getName();
                    if (name.endsWith(".apk")) found.add(name);
                    else if (name.endsWith(".obb")) bundle.obbCount++;
                }
                for (String name : select(found)) {
                    // Своё имя файла вместо пути из архива — защита от выхода за пределы папки.
                    File part = new File(bundle.dir, "part" + bundle.apks.size() + ".apk");
                    try (InputStream src = zip.getInputStream(zip.getEntry(name));
                         OutputStream dst = new FileOutputStream(part)) {
                        copy(src, dst, null);
                    }
                    bundle.apks.add(part);
                    names.add(name.substring(name.lastIndexOf('/') + 1));
                }
            }
        } catch (ZipException e) {
            throw new IOException("Это не APK и не архив с APK");
        }

        if (single) {
            File apk = new File(bundle.dir, "base.apk");
            if (!input.renameTo(apk)) throw new IOException("Не удалось подготовить файл");
            bundle.apks.add(apk);
            names.add("base.apk");
        } else if (!input.delete()) {
            input.deleteOnExit();
        }

        bundle.readInfo(context.getPackageManager(), names);
        return bundle;
    }

    /** Выбирает из архива только те части, которые можно ставить вместе на этот телефон. */
    private static List<String> select(List<String> names) throws IOException {
        List<String> picked = new ArrayList<>();
        if (names.contains("universal.apk")) {
            picked.add("universal.apk");
            return picked;
        }
        boolean bundletool = false;
        for (String name : names) {
            if (name.startsWith("splits/")) bundletool = true;
        }
        for (String name : names) {
            boolean fits = bundletool
                    ? name.startsWith("splits/") && !VARIANT.matcher(name).find()
                    : !name.startsWith("standalones/");
            if (fits) picked.add(name);
        }

        Set<String> available = new HashSet<>();
        for (String name : picked) {
            Matcher m = ABI.matcher(name);
            if (m.find()) available.add(m.group(1));
        }
        if (!available.isEmpty()) {
            String best = null;
            for (String abi : Build.SUPPORTED_ABIS) {
                String key = abi.replace('-', '_');
                if (available.contains(key)) {
                    best = key;
                    break;
                }
            }
            if (best == null) throw new IOException("В архиве нет библиотек под процессор этого телефона");
            String wanted = best;
            picked.removeIf(name -> {
                Matcher m = ABI.matcher(name);
                return m.find() && !m.group(1).equals(wanted);
            });
        }
        if (picked.isEmpty()) throw new IOException("В архиве нет APK-файлов");
        return picked;
    }

    private void readInfo(PackageManager pm, List<String> names) throws IOException {
        // Сначала пробуем самые вероятные кандидаты на главный APK.
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < apks.size(); i++) order.add(i);
        order.sort((a, b) -> {
            int byRank = Integer.compare(rank(names.get(a)), rank(names.get(b)));
            return byRank != 0 ? byRank : Long.compare(apks.get(b).length(), apks.get(a).length());
        });

        PackageInfo info = null;
        File base = null;
        for (int i : order) {
            info = pm.getPackageArchiveInfo(apks.get(i).getAbsolutePath(), PackageManager.GET_PERMISSIONS);
            if (info != null && info.applicationInfo != null) {
                base = apks.get(i);
                break;
            }
        }
        if (base == null) {
            throw new IOException("Не удалось прочитать APK: файл повреждён или требует более новый Android");
        }

        ApplicationInfo ai = info.applicationInfo;
        ai.sourceDir = base.getAbsolutePath();
        ai.publicSourceDir = base.getAbsolutePath();

        packageName = info.packageName;
        label = String.valueOf(ai.loadLabel(pm));
        icon = ai.loadIcon(pm);
        versionName = info.versionName == null ? "?" : info.versionName;
        versionCode = versionCode(info);
        minSdk = ai.minSdkVersion;
        targetSdk = ai.targetSdkVersion;
        if (info.requestedPermissions != null) {
            for (String permission : info.requestedPermissions) {
                permissions.add(permission.replace("android.permission.", ""));
            }
        }
        for (File apk : apks) size += apk.length();
    }

    private static int rank(String name) {
        if (name.equals("base.apk") || name.equals("base-master.apk") || name.equals("universal.apk")) return 0;
        return name.contains("config.") || ABI.matcher(name).find() ? 2 : 1;
    }

    @SuppressWarnings("deprecation")
    static long versionCode(PackageInfo info) {
        return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
    }

    /** Сохраняет установленное приложение: один APK как есть, несколько частей — одним .apks. */
    static void export(Context context, String packageName, OutputStream out)
            throws IOException, PackageManager.NameNotFoundException {
        ApplicationInfo ai = context.getPackageManager().getApplicationInfo(packageName, 0);
        if (ai.splitSourceDirs == null || ai.splitSourceDirs.length == 0) {
            try (InputStream in = new FileInputStream(ai.sourceDir)) {
                copy(in, out, null);
            }
            return;
        }
        try (ZipOutputStream zip = new ZipOutputStream(out)) {
            zip.setLevel(Deflater.NO_COMPRESSION);
            addToZip(zip, new File(ai.sourceDir), "base.apk");
            for (String path : ai.splitSourceDirs) {
                File file = new File(path);
                addToZip(zip, file, file.getName());
            }
        }
    }

    private static void addToZip(ZipOutputStream zip, File file, String name) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        try (InputStream in = new FileInputStream(file)) {
            copy(in, zip, null);
        }
        zip.closeEntry();
    }

    static void copy(InputStream in, OutputStream out, LongConsumer progress) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        long reported = 0;
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
            total += read;
            if (progress != null && total - reported >= 1 << 20) {
                reported = total;
                progress.accept(total);
            }
        }
    }

    private static File workDir(Context context) {
        return new File(context.getCacheDir(), "work");
    }

    static long cacheSize(Context context) {
        return sizeOf(workDir(context));
    }

    static void clearCache(Context context) {
        deleteRecursively(workDir(context));
    }

    void delete() {
        deleteRecursively(dir);
    }

    private static long sizeOf(File file) {
        File[] children = file.listFiles();
        if (children == null) return file.length();
        long sum = 0;
        for (File child : children) sum += sizeOf(child);
        return sum;
    }

    private static void deleteRecursively(File file) {
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) deleteRecursively(child);
        }
        if (file.exists() && !file.delete()) file.deleteOnExit();
    }
}
