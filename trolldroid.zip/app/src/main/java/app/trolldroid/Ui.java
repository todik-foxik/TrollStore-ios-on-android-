package app.trolldroid;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Кирпичики оформления «как в iOS». Цвета лежат в res/values и res/values-night. */
final class Ui {
    private final Context context;
    final int bg, card, label, secondary, separator, tint, red, pressed;

    Ui(Context context) {
        this.context = context;
        bg = context.getColor(R.color.bg);
        card = context.getColor(R.color.card);
        label = context.getColor(R.color.label);
        secondary = context.getColor(R.color.secondary);
        separator = context.getColor(R.color.separator);
        tint = context.getColor(R.color.tint);
        red = context.getColor(R.color.red);
        pressed = context.getColor(R.color.pressed);
    }

    int dp(float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    LinearLayout column() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    LinearLayout row() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    TextView text(String value, float sp, int color) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        return view;
    }

    GradientDrawable rounded(int color, float radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    Drawable ripple(Drawable content) {
        return new RippleDrawable(ColorStateList.valueOf(pressed), content, null);
    }

    /** Фон строки сгруппированного списка: скругления только у крайних. */
    Drawable cell(boolean first, boolean last) {
        float top = first ? dp(12) : 0;
        float bottom = last ? dp(12) : 0;
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(card);
        shape.setCornerRadii(new float[]{top, top, top, top, bottom, bottom, bottom, bottom});
        return ripple(shape);
    }

    /** Тонкий разделитель с отступом слева. */
    View line(float inset) {
        View view = new View(context);
        view.setBackgroundColor(separator);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.5f)));
        params.leftMargin = dp(inset);
        view.setLayoutParams(params);
        return view;
    }

    TextView button(String value, int textColor, int background, float radius) {
        TextView view = text(value, 18, textColor);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(16), dp(14), dp(16), dp(14));
        view.setBackground(ripple(rounded(background, radius)));
        return view;
    }

    /** Иконка, название и подпись. */
    LinearLayout appRow(Drawable icon, String title, String subtitle) {
        LinearLayout row = row();
        row.setPadding(dp(14), dp(10), dp(14), dp(10));

        ImageView image = new ImageView(context);
        image.setImageDrawable(icon);
        row.addView(image, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = column();
        texts.setPadding(dp(12), 0, dp(8), 0);
        TextView name = text(title, 17, label);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(name);
        TextView details = text(subtitle, 13, secondary);
        details.setSingleLine(true);
        details.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        texts.addView(details);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return row;
    }

    LinearLayout valueRow(String title, String value) {
        LinearLayout row = row();
        row.setPadding(dp(16), dp(14), dp(16), dp(14));
        row.setBackground(cell(true, true));
        row.addView(text(title, 17, label),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(text(value, 17, secondary));
        return row;
    }

    TextView section(String value) {
        TextView view = text(value, 13, secondary);
        view.setPadding(dp(16), dp(18), dp(16), dp(6));
        return view;
    }
}
