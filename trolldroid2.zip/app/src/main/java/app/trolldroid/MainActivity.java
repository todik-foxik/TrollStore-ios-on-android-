package app.trolldroid;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements InstallReceiver.Listener {
    private static final int REQUEST_PICK = 1;
    private static final int REQUEST_EXPORT = 2;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    /** Установка, скачивание и экспорт идут по очереди; список грузится отдельно, чтобы их не ждать. */
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor();

    private static final class AppItem {
        String pkg;
        String label;
        String version;
        Drawable icon;
    }

    private interface Source {
        InputStream open() throws IOException;
    }

    private final List<AppItem> allApps = new ArrayList<>();
    private final List<AppItem> apps = new ArrayList<>(); // то, что видно с учётом поиска
    private final BaseAdapter adapter = new AppAdapter();

    private Ui ui;
    private TextView title, plus, empty, appsTab, settingsTab, progressText;
    private ListView list;
    private ScrollView settingsScroll;
    private LinearLayout page, searchBar, settingsBox;
    private View headerLine;
    private EditText search;
    private Dialog sheet, progress;
    private boolean onSettings;
    private boolean loaded;
    private int loadGeneration;
    private String exportPackage;

    // ---------- Жизненный цикл ----------

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ui = new Ui(this);
        setContentView(buildLayout());
        InstallReceiver.listener = this;
        if (state != null) exportPackage = state.getString("exportPackage");
        showTab(state != null && state.getBoolean("onSettings"));
        if (state == null) handleIntent(getIntent());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("exportPackage", exportPackage);
        out.putBoolean("onSettings", onSettings);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onDestroy() {
        if (InstallReceiver.listener == this) InstallReceiver.listener = null;
        hideProgress();
        if (sheet != null) sheet.dismiss();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        if (request == REQUEST_PICK) openUri(data.getData());
        else if (request == REQUEST_EXPORT) export(exportPackage, data.getData());
    }

    /** «Открыть в TrollDroid» из файлового менеджера или «Поделиться». */
    @SuppressWarnings("deprecation")
    private void handleIntent(Intent intent) {
        // При открытии из «недавних» не предлагаем установить тот же файл повторно.
        if (intent == null || (intent.getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri != null) openUri(uri);
    }

    // ---------- Главный экран ----------

    @SuppressWarnings("deprecation")
    private View buildLayout() {
        page = ui.column();
        // Корень забирает фокус, чтобы клавиатура не выскакивала сама из-за поля поиска.
        page.setFocusableInTouchMode(true);

        // Маленький заголовок по центру, как в навигационной панели iOS.
        FrameLayout header = new FrameLayout(this);
        title = ui.text("", 17, ui.label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        header.addView(title, new FrameLayout.LayoutParams(MATCH, ui.dp(48)));
        plus = ui.text("+", 30, ui.tint);
        plus.setGravity(Gravity.CENTER);
        plus.setContentDescription("Установить приложение");
        plus.setBackground(ui.ripple(ui.rounded(ui.bg, 24)));
        plus.setOnClickListener(v -> {
            hideKeyboard();
            showAddSheet();
        });
        header.addView(plus, new FrameLayout.LayoutParams(ui.dp(56), ui.dp(48), Gravity.END));
        page.addView(header, ui.matchWrap());

        searchBar = buildSearchBar();
        LinearLayout.LayoutParams searchParams = ui.matchWrap();
        searchParams.setMargins(ui.dp(16), 0, ui.dp(16), ui.dp(10));
        page.addView(searchBar, searchParams);

        headerLine = ui.line(0);
        page.addView(headerLine);

        FrameLayout content = new FrameLayout(this);
        content.setBackgroundColor(ui.bg);

        list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setAdapter(adapter);
        content.addView(list, new FrameLayout.LayoutParams(MATCH, MATCH));

        empty = ui.text("", 16, ui.secondary);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(ui.dp(40), 0, ui.dp(40), ui.dp(60));
        content.addView(empty, new FrameLayout.LayoutParams(MATCH, MATCH));

        settingsScroll = new ScrollView(this);
        settingsBox = ui.column();
        settingsBox.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(32));
        settingsScroll.addView(settingsBox);
        content.addView(settingsScroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        page.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1));
        page.addView(ui.line(0));

        LinearLayout tabs = ui.row();
        tabs.setBackgroundColor(ui.bar);
        appsTab = tab("Приложения", R.drawable.ic_apps, false);
        settingsTab = tab("Настройки", R.drawable.ic_settings, true);
        tabs.addView(appsTab, new LinearLayout.LayoutParams(0, WRAP, 1));
        tabs.addView(settingsTab, new LinearLayout.LayoutParams(0, WRAP, 1));
        page.addView(tabs, ui.matchWrap());

        // На Android 15+ экран рисуется под системными панелями и клавиатурой — отступаем сами.
        page.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            int keyboard = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
                keyboard = insets.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top, right, keyboard);
            tabs.setPadding(0, 0, 0, bottom);
            tabs.setVisibility(keyboard > 0 ? View.GONE : View.VISIBLE);
            return insets;
        });
        return page;
    }

    private LinearLayout buildSearchBar() {
        LinearLayout bar = ui.row();
        bar.setBackground(ui.rounded(ui.field, 10));
        bar.setPadding(ui.dp(9), 0, ui.dp(9), 0);

        ImageView glass = new ImageView(this);
        glass.setImageResource(R.drawable.ic_search);
        bar.addView(glass, new LinearLayout.LayoutParams(ui.dp(18), ui.dp(18)));

        search = new EditText(this);
        search.setBackground(null);
        search.setHint("Поиск");
        search.setHintTextColor(ui.secondary);
        search.setTextColor(ui.label);
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        search.setPadding(ui.dp(7), 0, 0, 0);
        search.setOnEditorActionListener((view, action, event) -> {
            hideKeyboard();
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                applyFilter();
            }
        });
        bar.addView(search, new LinearLayout.LayoutParams(0, ui.dp(38), 1));
        return bar;
    }

    private void hideKeyboard() {
        if (search.getWindowToken() == null) return;
        InputMethodManager keyboard = getSystemService(InputMethodManager.class);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
    }

    private TextView tab(String text, int icon, boolean settings) {
        TextView tab = ui.text(text, 11, ui.secondary);
        tab.setGravity(Gravity.CENTER);
        tab.setPadding(0, ui.dp(7), 0, ui.dp(5));
        tab.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0);
        tab.setOnClickListener(v -> showTab(settings));
        return tab;
    }

    @SuppressWarnings("deprecation")
    private void showTab(boolean settings) {
        onSettings = settings;
        hideKeyboard();
        // У настроек панель сверху серая, у списка приложений — чёрная, как в TrollStore.
        int top = settings ? ui.bar : ui.bg;
        page.setBackgroundColor(top);
        getWindow().setStatusBarColor(top);
        title.setText(settings ? "Настройки" : "Приложения");
        plus.setVisibility(settings ? View.GONE : View.VISIBLE);
        searchBar.setVisibility(settings ? View.GONE : View.VISIBLE);
        headerLine.setVisibility(settings ? View.VISIBLE : View.GONE);
        list.setVisibility(settings ? View.GONE : View.VISIBLE);
        settingsScroll.setVisibility(settings ? View.VISIBLE : View.GONE);
        empty.setVisibility(View.GONE);
        highlight(appsTab, !settings);
        highlight(settingsTab, settings);
        refresh();
    }

    private void highlight(TextView tab, boolean active) {
        int color = active ? ui.tint : ui.secondary;
        tab.setTextColor(color);
        tab.setCompoundDrawableTintList(ColorStateList.valueOf(color));
    }

    private void refresh() {
        if (onSettings) buildSettings();
        else loadApps();
    }

    // ---------- Список приложений ----------

    private void loadApps() {
        boolean all = prefs().getBoolean("showAll", false);
        int generation = ++loadGeneration;
        int iconSize = ui.dp(58);
        Context app = getApplicationContext();
        LOADER.execute(() -> {
            List<AppItem> result = queryApps(app, all, iconSize);
            runOnUiThread(() -> {
                if (generation != loadGeneration || isDestroyed()) return;
                allApps.clear();
                allApps.addAll(result);
                loaded = true;
                applyFilter();
            });
        });
    }

    private void applyFilter() {
        String query = search.getText().toString().trim().toLowerCase(Locale.getDefault());
        apps.clear();
        for (AppItem item : allApps) {
            if (query.isEmpty() || item.label.toLowerCase(Locale.getDefault()).contains(query)
                    || item.pkg.toLowerCase(Locale.ROOT).contains(query)) {
                apps.add(item);
            }
        }
        adapter.notifyDataSetChanged();
        if (!loaded) return;
        if (!query.isEmpty()) {
            empty.setText("Ничего не найдено");
        } else if (prefs().getBoolean("showAll", false)) {
            empty.setText("Сторонних приложений не найдено");
        } else {
            empty.setText("Здесь появятся приложения, установленные через TrollDroid.\n\nНажми + и выбери .apk, .apks, .xapk или .apkm");
        }
        empty.setVisibility(!onSettings && apps.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private static List<AppItem> queryApps(Context context, boolean all, int iconSize) {
        PackageManager pm = context.getPackageManager();
        String self = context.getPackageName();
        List<AppItem> result = new ArrayList<>();
        for (PackageInfo info : pm.getInstalledPackages(0)) {
            ApplicationInfo ai = info.applicationInfo;
            if (ai == null || self.equals(info.packageName)) continue;
            if (all) {
                if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            } else {
                if (!self.equals(installerOf(pm, info.packageName))) continue;
            }
            AppItem item = new AppItem();
            item.pkg = info.packageName;
            item.label = String.valueOf(ai.loadLabel(pm));
            item.version = info.versionName == null ? "?" : info.versionName;
            item.icon = Ui.roundIcon(context.getResources(), ai.loadIcon(pm), iconSize);
            result.add(item);
        }
        Collator collator = Collator.getInstance();
        result.sort((a, b) -> collator.compare(a.label, b.label));
        return result;
    }

    @SuppressWarnings("deprecation")
    private static String installerOf(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) return pm.getInstallSourceInfo(pkg).getInstallingPackageName();
            return pm.getInstallerPackageName(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public Object getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View recycled, ViewGroup parent) {
            AppItem item = apps.get(position);
            LinearLayout cell = ui.column();
            LinearLayout row = ui.appRow(item.icon, item.label, item.version + " • " + item.pkg, 58, ui.label);
            row.setPadding(ui.dp(10), ui.dp(11), ui.dp(12), ui.dp(11));
            cell.addView(row, ui.matchWrap());
            cell.addView(ui.line(82));
            cell.setBackground(ui.ripple(new ColorDrawable(ui.bg)));
            cell.setOnClickListener(v -> {
                hideKeyboard();
                showAppSheet(item);
            });
            return cell;
        }
    }

    // ---------- Шторки ----------

    /** Карточка снизу в духе iOS action sheet. */
    private void showSheet(LinearLayout card, View... buttons) {
        if (isFinishing() || isDestroyed()) return;
        if (sheet != null) sheet.dismiss();
        sheet = new Dialog(this);
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = ui.column();
        box.setPadding(ui.dp(10), ui.dp(10), ui.dp(10), ui.dp(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(ui.rounded(ui.card, 14));
        scroll.setClipToOutline(true);
        scroll.addView(card);
        box.addView(scroll, new LinearLayout.LayoutParams(MATCH, WRAP, 1));

        for (View button : buttons) {
            LinearLayout.LayoutParams params = ui.matchWrap();
            params.topMargin = ui.dp(8);
            box.addView(button, params);
        }

        sheet.setContentView(box);
        Window window = sheet.getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(MATCH, WRAP);
        sheet.show();
    }

    private void addAction(LinearLayout card, String text, int color, Runnable action) {
        card.addView(ui.line(0));
        TextView button = ui.button(text, color, ui.card, 0);
        button.setOnClickListener(v -> {
            sheet.dismiss();
            action.run();
        });
        card.addView(button, ui.matchWrap());
    }

    private TextView cancelButton() {
        TextView button = ui.button("Отмена", ui.tint, ui.card, 14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setOnClickListener(v -> sheet.dismiss());
        return button;
    }

    private void showAddSheet() {
        LinearLayout card = ui.column();
        TextView hint = ui.text("Установить .apk, .apks, .xapk или .apkm", 13, ui.secondary);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14));
        card.addView(hint, ui.matchWrap());
        addAction(card, "Из файла", ui.tint, this::pickFile);
        addAction(card, "По ссылке", ui.tint, this::askUrl);
        showSheet(card, cancelButton());
    }

    private void showAppSheet(AppItem item) {
        LinearLayout card = ui.column();
        card.addView(ui.appRow(item.icon, item.label, item.version + " • " + item.pkg, 46, ui.secondary));
        addAction(card, "Открыть", ui.tint, () -> openApp(item.pkg));
        addAction(card, "О приложении", ui.tint, () -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", item.pkg, null))));
        addAction(card, "Сохранить APK", ui.tint, () -> pickExportTarget(item));
        addAction(card, "Удалить", ui.red, () -> startActivity(new Intent(
                Intent.ACTION_DELETE, Uri.fromParts("package", item.pkg, null))));
        showSheet(card, cancelButton());
    }

    private void showInstallSheet(ApkBundle bundle) {
        LinearLayout card = ui.column();
        Drawable icon = Ui.roundIcon(getResources(), bundle.icon, ui.dp(46));
        card.addView(ui.appRow(icon, bundle.label, bundle.packageName, 46, ui.secondary));
        card.addView(ui.line(0));
        addInfo(card, "Версия", bundle.versionName);
        addInfo(card, "Действие", installKind(bundle));
        addInfo(card, "Размер", formatSize(bundle.size));
        addInfo(card, "API", "минимум " + bundle.minSdk + ", целевой " + bundle.targetSdk);
        if (bundle.apks.size() > 1) addInfo(card, "Частей APK", String.valueOf(bundle.apks.size()));
        addInfo(card, "Разрешения", bundle.permissions.isEmpty() ? "нет" : TextUtils.join("\n", bundle.permissions));
        if (bundle.obbCount > 0) {
            addInfo(card, "Внимание", "В архиве есть OBB-файлы. Они не копируются — игра может не запуститься или начать докачку.");
        }

        TextView install = ui.button("Установить", Color.WHITE, ui.tint, 14);
        install.setTypeface(Typeface.DEFAULT_BOLD);
        install.setOnClickListener(v -> startInstall(bundle));
        showSheet(card, install, cancelButton());
    }

    private void addInfo(LinearLayout card, String name, String value) {
        LinearLayout row = ui.row();
        row.setGravity(Gravity.TOP);
        row.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8));
        row.addView(ui.text(name, 15, ui.secondary), new LinearLayout.LayoutParams(ui.dp(110), WRAP));
        row.addView(ui.text(value, 15, ui.label), new LinearLayout.LayoutParams(0, WRAP, 1));
        card.addView(row, ui.matchWrap());
    }

    private String installKind(ApkBundle bundle) {
        try {
            PackageInfo old = getPackageManager().getPackageInfo(bundle.packageName, 0);
            long oldCode = ApkBundle.versionCode(old);
            if (bundle.versionCode > oldCode) return "Обновление с " + old.versionName;
            if (bundle.versionCode == oldCode) return "Переустановка той же версии";
            return "Откат на старую версию — Android не даст, сначала удали новую";
        } catch (PackageManager.NameNotFoundException e) {
            return "Новая установка";
        }
    }

    // ---------- Открытие файла и установка ----------

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_PICK);
    }

    private void askUrl() {
        EditText input = new EditText(this);
        input.setHint("https://…/app.apk");
        input.setHintTextColor(ui.secondary);
        input.setTextColor(ui.label);
        input.setTextSize(15);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setBackground(ui.rounded(ui.bg, 8));
        input.setPadding(ui.dp(10), ui.dp(9), ui.dp(10), ui.dp(9));
        Dialog dialog = iosAlert("Установить по ссылке", "Прямая ссылка на APK или архив", input,
                "Отмена", "Скачать", () -> download(input.getText().toString().trim()));
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        input.requestFocus();
    }

    private void download(String address) {
        if (!address.startsWith("https://")) {
            alert("Нужна другая ссылка", "Поддерживаются только прямые ссылки https://");
            return;
        }
        load("Скачиваю…", () -> {
            HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            int code = connection.getResponseCode();
            if (code != HttpURLConnection.HTTP_OK) throw new IOException("Сервер ответил кодом " + code);
            return connection.getInputStream();
        });
    }

    private void openUri(Uri uri) {
        load("Читаю файл…", () -> getContentResolver().openInputStream(uri));
    }

    private void load(String message, Source source) {
        if (sheet != null) sheet.dismiss();
        showProgress(message);
        Context app = getApplicationContext();
        IO.execute(() -> {
            try (InputStream in = source.open()) {
                if (in == null) throw new IOException("Не удалось открыть файл");
                ApkBundle bundle = ApkBundle.load(app, in, bytes ->
                        runOnUiThread(() -> updateProgress(message + " " + formatSize(bytes))));
                runOnUiThread(() -> {
                    hideProgress();
                    showInstallSheet(bundle);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideProgress();
                    alert("Не получилось открыть", describe(e));
                });
            }
        });
    }

    private void startInstall(ApkBundle bundle) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            iosAlert("Нужно разрешение",
                    "Разреши TrollDroid устанавливать приложения, вернись сюда и нажми «Установить» ещё раз.",
                    null, "Отмена", "Настройки", this::openInstallPermission);
            return;
        }
        sheet.dismiss();
        showProgress("Устанавливаю…");
        Context app = getApplicationContext();
        IO.execute(() -> {
            try {
                Installer.install(app, bundle);
                bundle.delete();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideProgress();
                    alert("Не получилось установить", describe(e));
                });
            }
        });
    }

    @Override
    public void onConfirmationNeeded() {
        hideProgress();
    }

    @Override
    public void onInstallFinished(boolean success, String message) {
        hideProgress();
        if (success) toast("Установлено ✓");
        else alert("Не установилось", message);
        refresh();
    }

    // ---------- Действия с приложением ----------

    private void openApp(String pkg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) toast("У этого приложения нет экрана запуска");
        else startActivity(launch);
    }

    private void pickExportTarget(AppItem item) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(item.pkg, 0);
            boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
            exportPackage = item.pkg;
            String name = (item.label + "_" + item.version).replaceAll("[\\\\/:*?\"<>|]", "_");
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/octet-stream");
            intent.putExtra(Intent.EXTRA_TITLE, name + (split ? ".apks" : ".apk"));
            startActivityForResult(intent, REQUEST_EXPORT);
        } catch (PackageManager.NameNotFoundException e) {
            toast("Приложение уже удалено");
        }
    }

    private void export(String pkg, Uri target) {
        if (pkg == null) return;
        showProgress("Сохраняю…");
        Context app = getApplicationContext();
        IO.execute(() -> {
            String error = null;
            try (OutputStream out = app.getContentResolver().openOutputStream(target)) {
                if (out == null) throw new IOException("Не удалось открыть файл для записи");
                ApkBundle.export(app, pkg, out);
            } catch (Exception e) {
                error = describe(e);
            }
            String result = error;
            runOnUiThread(() -> {
                hideProgress();
                if (result == null) toast("Сохранено ✓");
                else alert("Не получилось сохранить", result);
            });
        });
    }

    // ---------- Настройки ----------

    private void buildSettings() {
        settingsBox.removeAllViews();

        LinearLayout install = addGroup("УСТАНОВКА");
        if (getPackageManager().canRequestPackageInstalls()) {
            ui.addRow(install, ui.groupRow("Установка приложений: разрешена", ui.secondary));
        } else {
            TextView allow = ui.groupRow("Разрешить установку приложений", ui.tint);
            allow.setOnClickListener(v -> openInstallPermission());
            ui.addRow(install, allow);
        }
        settingsBox.addView(ui.footer("Без этого разрешения Android не даст TrollDroid ставить приложения."));

        LinearLayout utilities = addGroup("УТИЛИТЫ");
        TextView clear = ui.groupRow("Очистить временные файлы", ui.tint);
        clear.setOnClickListener(v -> {
            ApkBundle.clearCache(this);
            buildSettings();
        });
        ui.addRow(utilities, clear);
        settingsBox.addView(ui.footer("Временные файлы занимают " + formatSize(ApkBundle.cacheSize(this)) + "."));

        LinearLayout listGroup = addGroup("СПИСОК");
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(16), ui.dp(8), ui.dp(12), ui.dp(8));
        row.addView(ui.text("Все сторонние приложения", 17, ui.label), new LinearLayout.LayoutParams(0, WRAP, 1));
        IosSwitch showAll = new IosSwitch(this, ui, prefs().getBoolean("showAll", false),
                checked -> prefs().edit().putBoolean("showAll", checked).apply());
        showAll.setContentDescription("Все сторонние приложения");
        row.addView(showAll);
        row.setOnClickListener(v -> showAll.performClick());
        ui.addRow(listGroup, row);
        settingsBox.addView(ui.footer("Если выключено, в списке только то, что установлено через TrollDroid."));

        LinearLayout about = addGroup("TROLLDROID");
        ui.addRow(about, ui.groupRow("Версия " + ownVersion(), ui.secondary));
        TextView remove = ui.groupRow("Удалить TrollDroid", ui.red);
        remove.setGravity(Gravity.CENTER);
        remove.setOnClickListener(v -> startActivity(new Intent(
                Intent.ACTION_DELETE, Uri.fromParts("package", getPackageName(), null))));
        ui.addRow(about, remove);
        settingsBox.addView(ui.footer("Приложения ставятся штатным установщиком Android. Без root и эксплойтов."));
    }

    private LinearLayout addGroup(String heading) {
        settingsBox.addView(ui.header(heading));
        LinearLayout group = ui.group();
        settingsBox.addView(group, ui.matchWrap());
        return group;
    }

    private String ownVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "?";
        }
    }

    private void openInstallPermission() {
        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.fromParts("package", getPackageName(), null)));
    }

    // ---------- Мелочи ----------

    private SharedPreferences prefs() {
        return getSharedPreferences("settings", MODE_PRIVATE);
    }

    private void showProgress(String message) {
        if (isFinishing() || isDestroyed()) return;
        hideProgress();
        LinearLayout box = ui.column();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(24), ui.dp(22), ui.dp(24), ui.dp(20));
        box.setBackground(ui.rounded(ui.card, 14));
        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(ui.secondary));
        box.addView(spinner, new LinearLayout.LayoutParams(ui.dp(36), ui.dp(36)));
        progressText = ui.text(message, 15, ui.label);
        progressText.setGravity(Gravity.CENTER);
        progressText.setPadding(0, ui.dp(12), 0, 0);
        box.addView(progressText, ui.matchWrap());

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setCancelable(false);
        present(progress, box);
    }

    private void updateProgress(String message) {
        if (progressText != null) progressText.setText(message);
    }

    private void hideProgress() {
        if (progress != null) progress.dismiss();
        progress = null;
    }

    private void alert(String heading, String message) {
        if (isFinishing() || isDestroyed()) return;
        iosAlert(heading, message, null, null, "OK", null);
    }

    /** Окно в духе iOS: заголовок, текст и кнопки в ряд. */
    private Dialog iosAlert(String heading, String message, View extra, String cancel, String ok, Runnable action) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout texts = ui.column();
        texts.setPadding(ui.dp(16), ui.dp(19), ui.dp(16), ui.dp(17));
        TextView head = ui.text(heading, 17, ui.label);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        head.setGravity(Gravity.CENTER);
        texts.addView(head, ui.matchWrap());
        TextView body = ui.text(message, 13, ui.label);
        body.setGravity(Gravity.CENTER);
        body.setPadding(0, ui.dp(6), 0, 0);
        texts.addView(body, ui.matchWrap());
        if (extra != null) {
            LinearLayout.LayoutParams params = ui.matchWrap();
            params.topMargin = ui.dp(14);
            texts.addView(extra, params);
        }

        LinearLayout box = ui.column();
        box.setBackground(ui.rounded(ui.card, 14));
        box.setClipToOutline(true);
        ScrollView scroll = new ScrollView(this); // длинный текст ошибки должен прокручиваться
        scroll.addView(texts);
        box.addView(scroll, new LinearLayout.LayoutParams(MATCH, WRAP, 1));
        box.addView(ui.line(0));

        LinearLayout buttons = ui.row();
        if (cancel != null) {
            TextView no = ui.button(cancel, ui.tint, ui.card, 0);
            no.setOnClickListener(v -> dialog.dismiss());
            buttons.addView(no, new LinearLayout.LayoutParams(0, WRAP, 1));
            buttons.addView(ui.verticalLine());
        }
        TextView yes = ui.button(ok, ui.tint, ui.card, 0);
        yes.setTypeface(Typeface.DEFAULT_BOLD);
        yes.setOnClickListener(v -> {
            dialog.dismiss();
            if (action != null) action.run();
        });
        buttons.addView(yes, new LinearLayout.LayoutParams(0, WRAP, 1));
        box.addView(buttons, ui.matchWrap());

        present(dialog, box);
        return dialog;
    }

    private void present(Dialog dialog, View content) {
        dialog.setContentView(content);
        Window window = dialog.getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(ui.dp(280), WRAP);
        dialog.show();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String formatSize(long bytes) {
        return Formatter.formatShortFileSize(this, bytes);
    }

    private static String describe(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
    }
}
