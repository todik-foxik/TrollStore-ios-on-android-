# Фото — iOS 18 style (native Android, Kotlin)

Нативное Android-приложение «Фото» в стиле iOS 18. Собирается в APK через
GitHub Actions (workflow распаковывает `gallery.zip` и запускает
`gradle assembleDebug`).

## Что внутри
- **Библиотека** — единая сетка всех фото устройства (3 колонки), большой
  заголовок, строка фильтров.
- **Альбомы** — реальные альбомы из галереи (обложка + название + количество).
- **Поиск** — строка поиска, плитки категорий, сетка недавних фото.
- **Просмотр фото** — на весь экран, свайп между фото (ViewPager2), тап
  скрывает/показывает панели в стиле iOS, кнопка «Поделиться».
- Тёмная тема (чёрный фон, синий акцент), доступ к галерее только на чтение.

## Стек
Kotlin, AndroidX (RecyclerView, ViewPager2, ConstraintLayout),
Material Components, Glide. minSdk 21 / targetSdk 34 / compileSdk 34.
AGP 8.5.2, Kotlin 1.9.24, Gradle 8.10.2.

## Как получить APK
См. инструкцию у ассистента. Кратко: залей `gallery.zip` в пустой репозиторий
GitHub (Add file → Upload files, **не распаковывай**), затем Add file → Create
new file `.github/workflows/build.yml` и вставь текст workflow. После пуша
зайди во вкладку **Actions** → после зелёной галочки открой **Releases** —
там будет `Gallery.apk`.
