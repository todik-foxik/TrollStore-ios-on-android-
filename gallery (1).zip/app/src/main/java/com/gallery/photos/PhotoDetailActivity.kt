package com.gallery.photos

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.gallery.photos.adapter.PhotoPagerAdapter
import com.gallery.photos.databinding.ActivityPhotoDetailBinding
import com.gallery.photos.model.Photo
import com.gallery.photos.util.DateUtil

class PhotoDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoDetailBinding
    private var chromeVisible = true
    private lateinit var pagerAdapter: PhotoPagerAdapter

    // Snapshot taken at activity creation so re-entering another viewer never
    // corrupts this one.
    private val photos: List<Photo> = shared

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val startIndex = intent.getIntExtra("index", 0)
            .coerceIn(0, (photos.size - 1).coerceAtLeast(0))

        pagerAdapter = PhotoPagerAdapter(photos) { toggleChrome() }
        binding.pager.adapter = pagerAdapter
        binding.pager.setCurrentItem(startIndex, false)
        updateDate(startIndex)

        binding.pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateDate(position)
        })

        binding.backBtn.setOnClickListener { finish() }
        binding.actionShare.setOnClickListener { shareCurrent() }
        binding.actionFav.setOnClickListener { toast("В разработке") }
        binding.actionInfo.setOnClickListener { toast("В разработке") }
        binding.actionDelete.setOnClickListener { toast("В разработке") }
    }

    private fun updateDate(position: Int) {
        if (photos.isEmpty()) {
            binding.dateText.text = ""
            return
        }
        val pos = position.coerceIn(0, photos.size - 1)
        binding.dateText.text = DateUtil.ruDate(photos[pos].date)
    }

    private fun toggleChrome() {
        chromeVisible = !chromeVisible
        val target = if (chromeVisible) 1f else 0f
        binding.topBar.animate().alpha(target).setDuration(180).start()
        binding.bottomBar.animate().alpha(target).setDuration(180).start()
    }

    private fun shareCurrent() {
        val pos = binding.pager.currentItem
        val photo = photos.getOrNull(pos) ?: return
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, photo.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, getString(R.string.action_share)))
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private var shared: List<Photo> = emptyList()

        fun start(context: Context, list: List<Photo>, index: Int) {
            shared = list
            context.startActivity(
                Intent(context, PhotoDetailActivity::class.java).putExtra("index", index)
            )
        }
    }
}
