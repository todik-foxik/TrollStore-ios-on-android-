package com.gallery.photos

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.gallery.photos.databinding.ActivityMainBinding
import com.gallery.photos.fragment.AlbumsFragment
import com.gallery.photos.fragment.LibraryFragment
import com.gallery.photos.fragment.SearchFragment
import com.gallery.photos.util.Perm

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* fragments reload in onResume */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.navView.setOnItemSelectedListener { item ->
            showFragment(item.itemId)
            true
        }

        if (savedInstanceState == null) {
            showFragment(R.id.nav_library)
        }

        if (!Perm.hasAccess(this)) {
            permLauncher.launch(Perm.needed())
        }
    }

    private fun showFragment(itemId: Int) {
        val fragment = when (itemId) {
            R.id.nav_albums -> AlbumsFragment()
            R.id.nav_search -> SearchFragment()
            else -> LibraryFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.nav_host, fragment)
            .commitAllowingStateLoss()
    }
}
