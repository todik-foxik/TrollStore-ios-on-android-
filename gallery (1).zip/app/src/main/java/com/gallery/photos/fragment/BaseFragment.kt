package com.gallery.photos.fragment

import android.view.View
import androidx.fragment.app.Fragment
import com.gallery.photos.databinding.ViewEmptyBinding

/** Shared empty / permission-state rendering for the three tab fragments. */
abstract class BaseFragment : Fragment() {

    protected abstract fun emptyBinding(): ViewEmptyBinding

    protected fun showEmpty(iconRes: Int, titleRes: Int, msgRes: Int, btnRes: Int) {
        val b = emptyBinding()
        b.emptyIcon.setImageResource(iconRes)
        b.emptyTitle.setText(titleRes)
        b.emptyMessage.setText(msgRes)
        if (btnRes != 0) {
            b.emptyButton.setText(btnRes)
            b.emptyButton.visibility = View.VISIBLE
        } else {
            b.emptyButton.visibility = View.GONE
        }
        b.root.visibility = View.VISIBLE
    }

    protected fun hideEmpty() {
        emptyBinding().root.visibility = View.GONE
    }
}
