package com.gallery.photos.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object Perm {

    fun hasAccess(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            granted(ctx, "android.permission.READ_MEDIA_IMAGES") ||
                granted(ctx, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
        } else {
            granted(ctx, "android.permission.READ_EXTERNAL_STORAGE")
        }
    }

    fun needed(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                "android.permission.READ_MEDIA_IMAGES",
                "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            )
        } else {
            arrayOf("android.permission.READ_EXTERNAL_STORAGE")
        }
    }

    private fun granted(ctx: Context, perm: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
}
