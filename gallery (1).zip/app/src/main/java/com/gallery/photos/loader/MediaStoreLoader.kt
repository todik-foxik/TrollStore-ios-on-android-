package com.gallery.photos.loader

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.gallery.photos.model.Album
import com.gallery.photos.model.Photo
import java.util.LinkedHashMap

/** Reads images from MediaStore (sorted newest-first). */
object MediaStoreLoader {

    private val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.DATE_TAKEN,
        MediaStore.Images.Media.BUCKET_ID,
        MediaStore.Images.Media.BUCKET_DISPLAY_NAME
    )

    private val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"

    fun loadAll(context: Context): List<Photo> {
        val result = ArrayList<Photo>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        runCatching {
            context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val bucketIdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                val bucketNameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: ""
                    val date = if (c.isNull(dateCol)) 0L else c.getLong(dateCol)
                    val bucketId = c.getString(bucketIdCol) ?: ""
                    val bucketName = c.getString(bucketNameCol) ?: ""
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                    )
                    result.add(Photo(id, uri, name, date, bucketId, bucketName))
                }
            }
        }
        return result
    }

    fun loadAlbums(context: Context): List<Album> {
        val map = LinkedHashMap<String, Album>()
        loadAll(context).forEach { p ->
            val album = map.getOrPut(p.bucketId) {
                Album(p.bucketId, p.bucketName.ifEmpty { "Без названия" }, mutableListOf())
            }
            album.photos.add(p)
        }
        return map.values.toList()
    }

    fun loadBucket(context: Context, bucketId: String): List<Photo> =
        loadAll(context).filter { it.bucketId == bucketId }
}
