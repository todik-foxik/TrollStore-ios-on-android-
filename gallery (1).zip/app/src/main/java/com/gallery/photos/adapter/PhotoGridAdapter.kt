package com.gallery.photos.adapter

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.databinding.ItemPhotoGridBinding
import com.gallery.photos.model.Photo

class PhotoGridAdapter(
    private val photos: List<Photo>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<PhotoGridAdapter.VH>() {

    private val placeholder = ColorDrawable(Color.parseColor("#1C1C1E"))

    inner class VH(val binding: ItemPhotoGridBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemPhotoGridBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val photo = photos[position]
        Glide.with(holder.itemView.context)
            .load(photo.uri)
            .placeholder(placeholder)
            .centerCrop()
            .into(holder.binding.photoImage)
        holder.binding.photoImage.setOnClickListener { onClick(position) }
    }

    override fun getItemCount(): Int = photos.size
}
