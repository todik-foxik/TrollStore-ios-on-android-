package com.gallery.photos.adapter

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.databinding.ItemAlbumBinding
import com.gallery.photos.model.Album

class AlbumAdapter(
    private val albums: List<Album>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<AlbumAdapter.VH>() {

    private val placeholder = ColorDrawable(Color.parseColor("#1C1C1E"))

    inner class VH(val binding: ItemAlbumBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemAlbumBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val album = albums[position]
        holder.binding.albumName.text = album.name
        holder.binding.albumCount.text = album.count.toString()
        val cover = album.cover
        if (cover != null) {
            Glide.with(holder.itemView.context)
                .load(cover.uri)
                .placeholder(placeholder)
                .centerCrop()
                .into(holder.binding.albumCover)
        } else {
            holder.binding.albumCover.setImageDrawable(null)
        }
        holder.binding.root.setOnClickListener { onClick(position) }
    }

    override fun getItemCount(): Int = albums.size
}
