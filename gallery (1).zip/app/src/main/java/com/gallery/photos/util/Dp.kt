package com.gallery.photos.util

import android.content.Context

/** dp → px helper. */
fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()
