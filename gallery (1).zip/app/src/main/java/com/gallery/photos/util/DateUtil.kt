package com.gallery.photos.util

import java.util.Calendar

object DateUtil {

    private val months = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )

    fun ruDate(ms: Long): String {
        if (ms <= 0L) return ""
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val day = c.get(Calendar.DAY_OF_MONTH)
        val month = c.get(Calendar.MONTH)
        val year = c.get(Calendar.YEAR)
        return "$day ${months[month]} $year"
    }
}
