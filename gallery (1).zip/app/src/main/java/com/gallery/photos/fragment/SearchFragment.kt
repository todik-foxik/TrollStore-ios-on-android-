package com.gallery.photos.fragment

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import com.gallery.photos.PhotoDetailActivity
import com.gallery.photos.R
import com.gallery.photos.adapter.CategoryAdapter
import com.gallery.photos.adapter.PhotoGridAdapter
import com.gallery.photos.databinding.FragmentSearchBinding
import com.gallery.photos.databinding.ViewEmptyBinding
import com.gallery.photos.loader.MediaStoreLoader
import com.gallery.photos.model.Category
import com.gallery.photos.model.Photo
import com.gallery.photos.util.GridSpacingItemDecoration
import com.gallery.photos.util.Perm
import com.gallery.photos.util.dp

class SearchFragment : BaseFragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!

    private val recent = mutableListOf<Photo>()
    private lateinit var recentAdapter: PhotoGridAdapter

    private val categories = listOf(
        Category("Избранное", R.drawable.ic_heart, Color.parseColor("#FF2D55"), Color.parseColor("#FFD9E0")),
        Category("Скриншоты", R.drawable.ic_camera, Color.parseColor("#007AFF"), Color.parseColor("#D7E3FF")),
        Category("Селфи", R.drawable.ic_selfie, Color.parseColor("#34C759"), Color.parseColor("#D7F4DE")),
        Category("Видео", R.drawable.ic_video, Color.parseColor("#FF9500"), Color.parseColor("#FFE9CC")),
        Category("Люди", R.drawable.ic_people, Color.parseColor("#AF52DE"), Color.parseColor("#EADCF6")),
        Category("Места", R.drawable.ic_places, Color.parseColor("#FF3B30"), Color.parseColor("#FFD9D7"))
    )

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* onResume reloads */ }

    override fun emptyBinding(): ViewEmptyBinding = binding.emptyState

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.categoriesGrid.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.categoriesGrid.addItemDecoration(GridSpacingItemDecoration(2, requireContext().dp(12), true))
        binding.categoriesGrid.adapter = CategoryAdapter(categories)

        recentAdapter = PhotoGridAdapter(recent) { pos ->
            PhotoDetailActivity.start(requireContext(), recent, pos)
        }
        binding.recentGrid.layoutManager = GridLayoutManager(requireContext(), 3)
        binding.recentGrid.addItemDecoration(GridSpacingItemDecoration(3, requireContext().dp(2), false))
        binding.recentGrid.adapter = recentAdapter

        binding.emptyState.emptyButton.setOnClickListener {
            permLauncher.launch(Perm.needed())
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun refresh() {
        if (!Perm.hasAccess(requireContext())) {
            binding.scroll.visibility = View.GONE
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.perm_title, R.string.perm_message, R.string.perm_button
            )
            return
        }
        val list = MediaStoreLoader.loadAll(requireContext()).take(30)
        recent.clear()
        recent.addAll(list)
        recentAdapter.notifyDataSetChanged()
        if (list.isEmpty()) {
            binding.scroll.visibility = View.GONE
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.empty_search, R.string.empty_search_msg, 0
            )
        } else {
            hideEmpty()
            binding.scroll.visibility = View.VISIBLE
        }
    }
}
