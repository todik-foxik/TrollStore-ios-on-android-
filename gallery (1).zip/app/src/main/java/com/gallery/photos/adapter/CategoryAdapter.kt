package com.gallery.photos.adapter

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.databinding.ItemCategoryBinding
import com.gallery.photos.model.Category

class CategoryAdapter(
    private val items: List<Category>
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    inner class VH(val binding: ItemCategoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCategoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val cat = items[position]
        holder.binding.categoryLabel.text = cat.name
        holder.binding.categoryIcon.setImageResource(cat.iconRes)
        holder.binding.categoryRoot.backgroundTintList = ColorStateList.valueOf(cat.tint)
        holder.binding.categoryIconBox.backgroundTintList = ColorStateList.valueOf(cat.color)
    }

    override fun getItemCount(): Int = items.size
}
