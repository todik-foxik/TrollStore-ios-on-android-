package com.gallery.photos.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import com.gallery.photos.AlbumActivity
import com.gallery.photos.R
import com.gallery.photos.adapter.AlbumAdapter
import com.gallery.photos.databinding.FragmentAlbumsBinding
import com.gallery.photos.databinding.ViewEmptyBinding
import com.gallery.photos.loader.MediaStoreLoader
import com.gallery.photos.model.Album
import com.gallery.photos.util.GridSpacingItemDecoration
import com.gallery.photos.util.Perm
import com.gallery.photos.util.dp

class AlbumsFragment : BaseFragment() {

    private var _binding: FragmentAlbumsBinding? = null
    private val binding get() = _binding!!

    private val albums = mutableListOf<Album>()
    private lateinit var adapter: AlbumAdapter

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* onResume reloads */ }

    override fun emptyBinding(): ViewEmptyBinding = binding.emptyState

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlbumsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = AlbumAdapter(albums) { pos -> AlbumActivity.start(requireContext(), albums[pos]) }
        binding.albumsGrid.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.albumsGrid.addItemDecoration(GridSpacingItemDecoration(2, requireContext().dp(16), true))
        binding.albumsGrid.adapter = adapter
        binding.emptyState.emptyButton.setOnClickListener {
            permLauncher.launch(Perm.needed())
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun refresh() {
        if (!Perm.hasAccess(requireContext())) {
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.perm_title, R.string.perm_message, R.string.perm_button
            )
            return
        }
        val list = MediaStoreLoader.loadAlbums(requireContext())
        albums.clear()
        albums.addAll(list)
        adapter.notifyDataSetChanged()
        if (list.isEmpty()) {
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.empty_albums, R.string.empty_albums_msg, 0
            )
        } else {
            hideEmpty()
        }
    }
}
