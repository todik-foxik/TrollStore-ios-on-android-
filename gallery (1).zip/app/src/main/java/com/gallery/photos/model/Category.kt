package com.gallery.photos.model

/** Decorative category tile on the Search tab. */
data class Category(
    val name: String,
    val iconRes: Int,
    val color: Int,
    val tint: Int
)
