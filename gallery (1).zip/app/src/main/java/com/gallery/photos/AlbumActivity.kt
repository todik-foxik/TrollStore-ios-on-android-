package com.gallery.photos

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.gallery.photos.adapter.PhotoGridAdapter
import com.gallery.photos.databinding.ActivityAlbumBinding
import com.gallery.photos.loader.MediaStoreLoader
import com.gallery.photos.model.Album
import com.gallery.photos.model.Photo
import com.gallery.photos.util.GridSpacingItemDecoration
import com.gallery.photos.util.Perm
import com.gallery.photos.util.dp

class AlbumActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAlbumBinding
    private val photos = mutableListOf<Photo>()
    private lateinit var adapter: PhotoGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAlbumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bucketId = intent.getStringExtra("bucketId") ?: ""
        val bucketName = intent.getStringExtra("bucketName") ?: getString(R.string.tab_albums)
        binding.albumTitle.text = bucketName
        binding.backBtn.setOnClickListener { finish() }

        adapter = PhotoGridAdapter(photos) { pos -> PhotoDetailActivity.start(this, photos, pos) }
        binding.grid.layoutManager = GridLayoutManager(this, 3)
        binding.grid.addItemDecoration(GridSpacingItemDecoration(3, dp(2), false))
        binding.grid.adapter = adapter

        binding.emptyState.emptyButton.visibility = View.GONE

        if (Perm.hasAccess(this)) {
            val list = MediaStoreLoader.loadBucket(this, bucketId)
            photos.clear()
            photos.addAll(list)
            adapter.notifyDataSetChanged()
            if (list.isEmpty()) {
                showEmpty(R.drawable.ic_photo_placeholder, R.string.empty_photos, R.string.empty_photos_msg)
            } else {
                binding.emptyState.root.visibility = View.GONE
            }
        } else {
            showEmpty(R.drawable.ic_photo_placeholder, R.string.perm_title, R.string.perm_message)
        }
    }

    private fun showEmpty(iconRes: Int, titleRes: Int, msgRes: Int) {
        binding.emptyState.emptyIcon.setImageResource(iconRes)
        binding.emptyState.emptyTitle.setText(titleRes)
        binding.emptyState.emptyMessage.setText(msgRes)
        binding.emptyState.emptyButton.visibility = View.GONE
        binding.emptyState.root.visibility = View.VISIBLE
    }

    companion object {
        fun start(context: Context, album: Album) {
            context.startActivity(
                Intent(context, AlbumActivity::class.java)
                    .putExtra("bucketId", album.bucketId)
                    .putExtra("bucketName", album.name)
            )
        }
    }
}
