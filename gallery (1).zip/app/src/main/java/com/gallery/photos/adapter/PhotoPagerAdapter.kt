package com.gallery.photos.adapter

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.model.Photo

/** Adapter for the full-screen ViewPager2 photo viewer. */
class PhotoPagerAdapter(
    private val photos: List<Photo>,
    private val onTap: () -> Unit
) : RecyclerView.Adapter<PhotoPagerAdapter.PageVH>() {

    private val placeholder = ColorDrawable(Color.BLACK)

    class PageVH(val image: ImageView) : RecyclerView.ViewHolder(image)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val image = ImageView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            setOnClickListener { onTap() }
        }
        return PageVH(image)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        Glide.with(holder.image.context)
            .load(photos[position].uri)
            .placeholder(placeholder)
            .into(holder.image)
    }

    override fun getItemCount(): Int = photos.size
}
