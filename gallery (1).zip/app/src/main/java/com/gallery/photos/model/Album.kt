package com.gallery.photos.model

class Album(
    val bucketId: String,
    val name: String,
    val photos: MutableList<Photo>
) {
    val count: Int get() = photos.size
    val cover: Photo? get() = photos.firstOrNull()
}
