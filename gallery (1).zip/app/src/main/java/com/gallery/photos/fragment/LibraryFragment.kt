package com.gallery.photos.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import com.gallery.photos.PhotoDetailActivity
import com.gallery.photos.R
import com.gallery.photos.adapter.PhotoGridAdapter
import com.gallery.photos.databinding.FragmentLibraryBinding
import com.gallery.photos.databinding.ViewEmptyBinding
import com.gallery.photos.loader.MediaStoreLoader
import com.gallery.photos.model.Photo
import com.gallery.photos.util.GridSpacingItemDecoration
import com.gallery.photos.util.Perm
import com.gallery.photos.util.dp

class LibraryFragment : BaseFragment() {

    private var _binding: FragmentLibraryBinding? = null
    private val binding get() = _binding!!

    private val photos = mutableListOf<Photo>()
    private lateinit var adapter: PhotoGridAdapter
    private var selectedChip = 0

    private val chipLabels = intArrayOf(
        R.string.filter_recent, R.string.filter_fav,
        R.string.filter_shots, R.string.filter_selfie
    )

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* onResume reloads */ }

    override fun emptyBinding(): ViewEmptyBinding = binding.emptyState

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLibraryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupChips()
        adapter = PhotoGridAdapter(photos) { pos -> openDetail(pos) }
        binding.grid.layoutManager = GridLayoutManager(requireContext(), 3)
        binding.grid.addItemDecoration(GridSpacingItemDecoration(3, requireContext().dp(2), false))
        binding.grid.adapter = adapter
        binding.emptyState.emptyButton.setOnClickListener {
            permLauncher.launch(Perm.needed())
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun refresh() {
        if (!Perm.hasAccess(requireContext())) {
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.perm_title, R.string.perm_message, R.string.perm_button
            )
            return
        }
        val list = MediaStoreLoader.loadAll(requireContext())
        photos.clear()
        photos.addAll(list)
        adapter.notifyDataSetChanged()
        if (list.isEmpty()) {
            showEmpty(
                R.drawable.ic_photo_placeholder,
                R.string.empty_photos, R.string.empty_photos_msg, 0
            )
        } else {
            hideEmpty()
        }
    }

    private fun setupChips() {
        val container = binding.chipsContainer
        container.removeAllViews()
        chipLabels.forEachIndexed { i, res ->
            val tv = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_chip, container, false) as TextView
            tv.setText(res)
            tv.isSelected = (i == selectedChip)
            tv.setOnClickListener {
                selectedChip = i
                for (j in 0 until container.childCount) {
                    (container.getChildAt(j) as TextView).isSelected = (j == i)
                }
            }
            container.addView(tv)
        }
    }

    private fun openDetail(position: Int) {
        PhotoDetailActivity.start(requireContext(), photos, position)
    }
}
