# Keep Glide. Keep Kotlin metadata.
-dontwarn com.bumptech.glide.**
-keep class com.gallery.photos.model.** { *; }
