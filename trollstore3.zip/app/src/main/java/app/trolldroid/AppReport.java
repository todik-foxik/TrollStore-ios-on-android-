package app.trolldroid;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Разделы окна о приложении, по мотивам TrollStore: что ему можно и к чему оно потянется. */
final class AppReport {
    static final int PLAIN = 0, WARNING = 1, DANGER = 2;

    static final class Line {
        final String text;
        final int level;

        Line(String text, int level) {
            this.text = text;
            this.level = level;
        }
    }

    static final class Section {
        final String title;
        final List<Line> lines = new ArrayList<>();

        Section(String title) {
            this.title = title;
        }

        Section add(String text, int level) {
            lines.add(new Line(text, level));
            return this;
        }
    }

    private static final String PREFIX = "android.permission.";

    /** Название для человека и разрешения, которые за ним стоят. */
    private static final String[][] PERSONAL = {
            {"Камера", "CAMERA"},
            {"Микрофон", "RECORD_AUDIO"},
            {"Местоположение", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "ACCESS_BACKGROUND_LOCATION"},
            {"Контакты и аккаунты", "READ_CONTACTS", "WRITE_CONTACTS", "GET_ACCOUNTS"},
            {"СМС", "READ_SMS", "SEND_SMS", "RECEIVE_SMS", "RECEIVE_MMS", "RECEIVE_WAP_PUSH"},
            {"Телефон и звонки", "READ_PHONE_STATE", "READ_PHONE_NUMBERS", "CALL_PHONE", "ANSWER_PHONE_CALLS"},
            {"Журнал звонков", "READ_CALL_LOG", "WRITE_CALL_LOG", "PROCESS_OUTGOING_CALLS"},
            {"Календарь", "READ_CALENDAR", "WRITE_CALENDAR"},
            {"Фото и файлы", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE", "READ_MEDIA_IMAGES",
                    "READ_MEDIA_VIDEO", "READ_MEDIA_AUDIO", "READ_MEDIA_VISUAL_USER_SELECTED"},
            {"Датчики и активность", "BODY_SENSORS", "ACTIVITY_RECOGNITION"},
            {"Устройства поблизости", "BLUETOOTH_CONNECT", "BLUETOOTH_SCAN", "BLUETOOTH_ADVERTISE",
                    "NEARBY_WIFI_DEVICES"},
    };

    /**
     * @param requested разрешения, которые приложение просит (полные имена)
     * @param guards    разрешения, которыми закрыты его службы и приёмники
     */
    static List<Section> build(Collection<String> requested, Collection<String> guards, int targetSdk) {
        Set<String> asked = new LinkedHashSet<>(requested);
        List<Section> sections = new ArrayList<>();

        Section sandbox = new Section("Песочница");
        if (asked.contains(PREFIX + "MANAGE_EXTERNAL_STORAGE")) {
            sandbox.add("Приложение просит доступ ко всем файлам на телефоне.", WARNING);
        } else {
            sandbox.add("Приложение работает в песочнице: видит свои файлы и то, на что получит разрешение.", PLAIN);
        }
        sections.add(sandbox);

        Section can = new Section("Возможности");
        if (guards.contains(PREFIX + "BIND_ACCESSIBILITY_SERVICE")) {
            can.add("Есть служба спец. возможностей: если её включить, приложение видит экран "
                    + "и может нажимать за тебя.", DANGER);
        }
        if (guards.contains(PREFIX + "BIND_DEVICE_ADMIN")) {
            can.add("Может просить права администратора устройства.", DANGER);
        }
        if (guards.contains(PREFIX + "BIND_NOTIFICATION_LISTENER_SERVICE")) {
            can.add("Может читать уведомления, если это разрешить.", WARNING);
        }
        if (guards.contains(PREFIX + "BIND_INPUT_METHOD")) {
            can.add("Это клавиатура: если выбрать её, она видит всё, что ты печатаешь.", WARNING);
        }
        if (guards.contains(PREFIX + "BIND_VPN_SERVICE")) {
            can.add("Может включить VPN и пропускать через себя трафик.", WARNING);
        }
        if (asked.contains(PREFIX + "REQUEST_INSTALL_PACKAGES")) {
            can.add("Может предлагать установить другие приложения.", WARNING);
        }
        if (asked.contains(PREFIX + "SYSTEM_ALERT_WINDOW")) {
            can.add("Может рисовать поверх других приложений.", WARNING);
        }
        if (asked.contains(PREFIX + "PACKAGE_USAGE_STATS")) {
            can.add("Может смотреть, какими приложениями ты пользуешься.", WARNING);
        }
        if (asked.contains(PREFIX + "WRITE_SETTINGS")) {
            can.add("Может менять системные настройки.", WARNING);
        }
        if (asked.contains(PREFIX + "RECEIVE_BOOT_COMPLETED")) {
            can.add("Может запускаться сам после включения телефона.", PLAIN);
        }
        if (can.lines.isEmpty()) can.add("Особых системных возможностей не видно.", PLAIN);
        sections.add(can);

        Section personal = new Section("Личные данные");
        for (String[] group : PERSONAL) {
            for (int i = 1; i < group.length; i++) {
                if (asked.contains(PREFIX + group[i])) {
                    personal.add(group[0], PLAIN);
                    break;
                }
            }
        }
        if (!personal.lines.isEmpty()) {
            // До Android 6 (targetSdk 23) разрешения выдавались все разом при установке.
            personal.lines.add(0, targetSdk < 23
                    ? new Line("Старое приложение: получит это сразу при установке, без вопросов:", DANGER)
                    : new Line("Может попросить доступ к этому:", WARNING));
            sections.add(personal);
        }

        Section all = new Section("Разрешения");
        if (asked.isEmpty()) all.add("Ничего не просит.", PLAIN);
        for (String permission : asked) {
            all.add(permission.startsWith(PREFIX) ? permission.substring(PREFIX.length()) : permission, PLAIN);
        }
        sections.add(all);
        return sections;
    }
}
