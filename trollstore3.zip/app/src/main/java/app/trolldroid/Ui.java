package app.trolldroid;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Кирпичики оформления «как в iOS». Цвета лежат в res/values/colors.xml (светлая тема)
 * и res/values-night/colors.xml (тёмная) — какие брать, решает сам Android.
 */
final class Ui {
    private final Context context;
    final int bg, grouped, card, bar, field, label, secondary, separator, tint, red, green, orange, off,
            highlight, alert, sheet, iconBorder;

    Ui(Context context) {
        this.context = context;
        bg = context.getColor(R.color.bg);
        grouped = context.getColor(R.color.grouped);
        card = context.getColor(R.color.card);
        bar = context.getColor(R.color.bar);
        field = context.getColor(R.color.field);
        label = context.getColor(R.color.label);
        secondary = context.getColor(R.color.secondary);
        separator = context.getColor(R.color.separator);
        tint = context.getColor(R.color.tint);
        red = context.getColor(R.color.red);
        green = context.getColor(R.color.green);
        orange = context.getColor(R.color.orange);
        off = context.getColor(R.color.off);
        highlight = context.getColor(R.color.highlight);
        alert = context.getColor(R.color.alert);
        sheet = context.getColor(R.color.sheet);
        iconBorder = context.getColor(R.color.icon_border);
    }

    int dp(float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    LinearLayout column() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    LinearLayout row() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    TextView text(String value, float sp, int color) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        return view;
    }

    GradientDrawable rounded(int color, float radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    /** Фон, который сереет под пальцем, как в iOS. */
    Drawable pressable(int color, float radius) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, rounded(highlight, radius));
        states.addState(new int[0], rounded(color, radius));
        return states;
    }

    /** Тонкий разделитель с отступом слева. */
    View line(float inset) {
        View view = new View(context);
        view.setBackgroundColor(separator);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.5f)));
        params.leftMargin = dp(inset);
        view.setLayoutParams(params);
        return view;
    }

    View verticalLine() {
        View view = new View(context);
        view.setBackgroundColor(separator);
        view.setLayoutParams(new LinearLayout.LayoutParams(
                Math.max(1, dp(0.5f)), ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /** Кнопка в меню или окне. */
    TextView button(String value, float sp, int textColor, int background, float height) {
        TextView view = text(value, sp, textColor);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(8), dp(12), dp(8));
        view.setMinHeight(dp(height));
        view.setBackground(pressable(background, 0));
        return view;
    }

    /** Строка списка приложений: крупная иконка, название и «версия • пакет». */
    LinearLayout appRow(Drawable icon, String title, String subtitle) {
        LinearLayout row = row();
        row.setPadding(dp(8), dp(10), dp(12), dp(10));

        ImageView image = new ImageView(context);
        image.setImageDrawable(icon);
        row.addView(image, new LinearLayout.LayoutParams(dp(60), dp(60)));

        LinearLayout texts = column();
        texts.setPadding(dp(15), 0, 0, 0);
        TextView name = text(title, 17, label);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(name);
        TextView details = text(subtitle, 12, label);
        details.setSingleLine(true);
        details.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        details.setPadding(0, dp(4), 0, 0);
        texts.addView(details);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return row;
    }

    // ---------- Сгруппированные списки, как в настройках iOS ----------

    LinearLayout group() {
        LinearLayout group = column();
        group.setBackground(rounded(card, 11));
        group.setClipToOutline(true);
        return group;
    }

    TextView groupRow(String value, int color) {
        TextView view = text(value, 17, color);
        view.setPadding(dp(16), dp(11), dp(16), dp(11));
        view.setMinHeight(dp(46));
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setBackground(pressable(card, 0));
        return view;
    }

    void addRow(LinearLayout group, View row) {
        if (group.getChildCount() > 0) group.addView(line(16));
        group.addView(row, matchWrap());
    }

    TextView header(String value) {
        TextView view = text(value, 13, secondary);
        view.setPadding(dp(16), dp(26), dp(16), dp(7));
        return view;
    }

    TextView footer(String value) {
        TextView view = text(value, 13, secondary);
        view.setPadding(dp(16), dp(7), dp(16), 0);
        return view;
    }

    /** Скругляет иконку по-айосовски, чтобы форма не зависела от лаунчера телефона. */
    static Drawable roundIcon(Resources resources, Drawable source, int size, int border) {
        if (source == null) return null;
        try {
            Bitmap square = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(square);
            boolean fullBleed = source instanceof AdaptiveIconDrawable;
            if (fullBleed) {
                // Слои адаптивной иконки в полтора раза больше видимой части.
                AdaptiveIconDrawable adaptive = (AdaptiveIconDrawable) source;
                int extra = size / 4;
                for (Drawable layer : new Drawable[]{adaptive.getBackground(), adaptive.getForeground()}) {
                    if (layer == null) continue;
                    layer.setBounds(-extra, -extra, size + extra, size + extra);
                    layer.draw(canvas);
                }
            } else {
                source.setBounds(0, 0, size, size);
                source.draw(canvas);
            }
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setShader(new BitmapShader(square, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            Bitmap result = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas rounded = new Canvas(result);
            float radius = size * 0.225f;
            rounded.drawRoundRect(0, 0, size, size, radius, radius, paint);
            if (fullBleed) {
                // Тонкая рамка, чтобы белые иконки не сливались с белым фоном.
                float width = Math.max(1f, size / 120f);
                Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
                edge.setStyle(Paint.Style.STROKE);
                edge.setStrokeWidth(width);
                edge.setColor(border);
                float half = width / 2;
                rounded.drawRoundRect(half, half, size - half, size - half, radius, radius, edge);
            }
            square.recycle();
            return new BitmapDrawable(resources, result);
        } catch (RuntimeException e) {
            return source; // некоторые прошивки отдают иконки, которые нельзя перерисовать
        }
    }
}
