package app.trolldroid;

import android.content.Context;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/** Строка списка, которую можно смахнуть влево, как в iOS: под ней красная кнопка «Удалить». */
final class SwipeRow extends FrameLayout {
    interface Listener {
        void onSwipeStart(SwipeRow row);
    }

    private final View content;
    private final View action;
    private final int actionWidth;
    private final int slop;
    private final Listener listener;
    private float downX, downY, startShift;
    private boolean dragging, open;

    /** content должен быть непрозрачным: он закрывает кнопку, пока строку не сдвинули. */
    SwipeRow(Context context, View content, View action, int actionWidth, Listener listener) {
        super(context);
        this.content = content;
        this.action = action;
        this.actionWidth = actionWidth;
        this.listener = listener;
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        action.setVisibility(INVISIBLE);
        addView(action, new FrameLayout.LayoutParams(actionWidth, 0, Gravity.END));
        addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);
        // Кнопка ровно по высоте строки.
        action.measure(MeasureSpec.makeMeasureSpec(actionWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(getMeasuredHeight(), MeasureSpec.EXACTLY));
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
            startShift = content.getTranslationX();
            dragging = false;
        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            startDragIfSideways(event);
        }
        return dragging;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int type = event.getActionMasked();
        if (type == MotionEvent.ACTION_MOVE) {
            if (!dragging) startDragIfSideways(event);
            if (dragging) {
                float shift = startShift + event.getX() - downX;
                content.setTranslationX(Math.max(-actionWidth, Math.min(0f, shift)));
            }
        } else if (type == MotionEvent.ACTION_UP || type == MotionEvent.ACTION_CANCEL) {
            if (dragging) settle(content.getTranslationX() < -actionWidth / 2f);
            dragging = false;
        }
        return true;
    }

    private void startDragIfSideways(MotionEvent event) {
        float dx = event.getX() - downX;
        float dy = event.getY() - downY;
        // Влево открываем; вправо тянуть есть смысл только уже открытую строку.
        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f && (dx < 0 || open)) {
            dragging = true;
            action.setVisibility(VISIBLE);
            getParent().requestDisallowInterceptTouchEvent(true); // чтобы список не прокручивался
            listener.onSwipeStart(this);
        }
    }

    private void settle(boolean show) {
        open = show;
        content.animate()
                .translationX(show ? -actionWidth : 0)
                .setDuration(180)
                .withEndAction(() -> {
                    if (!open) action.setVisibility(INVISIBLE);
                });
    }

    boolean isOpen() {
        return open;
    }

    void close() {
        settle(false);
    }
}
