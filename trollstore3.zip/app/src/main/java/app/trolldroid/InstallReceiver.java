package app.trolldroid;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

/** Получает от системы ход и результат установки. */
public class InstallReceiver extends BroadcastReceiver {
    interface Listener {
        void onConfirmationNeeded();

        void onInstallFinished(boolean success, String message);
    }

    static Listener listener;

    @Override
    @SuppressWarnings("deprecation")
    public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            if (listener != null) listener.onConfirmationNeeded();
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) context.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }

        boolean success = status == PackageInstaller.STATUS_SUCCESS;
        String message = success ? "" : explain(status, intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
        if (listener != null) {
            listener.onInstallFinished(success, message);
        } else {
            Toast.makeText(context, success ? "Установлено" : message, Toast.LENGTH_LONG).show();
        }
    }

    private static String explain(int status, String details) {
        String reason;
        switch (status) {
            case PackageInstaller.STATUS_FAILURE_ABORTED:
                reason = "Установка отменена.";
                break;
            case PackageInstaller.STATUS_FAILURE_BLOCKED:
                reason = "Установку заблокировала система или Play Защита.";
                break;
            case PackageInstaller.STATUS_FAILURE_CONFLICT:
                reason = "Конфликт с уже установленным приложением (чаще всего другая подпись). Удали старое и попробуй снова.";
                break;
            case PackageInstaller.STATUS_FAILURE_INCOMPATIBLE:
                reason = "Приложение не подходит этому телефону (версия Android или процессор).";
                break;
            case PackageInstaller.STATUS_FAILURE_INVALID:
                reason = "APK повреждён, не подписан или набор частей неполный.";
                break;
            case PackageInstaller.STATUS_FAILURE_STORAGE:
                reason = "Не хватает места.";
                break;
            default:
                reason = "Система отклонила установку.";
        }
        return details == null ? reason : reason + "\n\n" + details;
    }
}
