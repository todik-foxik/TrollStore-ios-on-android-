package app.trolldroid;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements InstallReceiver.Listener {
    private static final int REQUEST_PICK = 1;
    private static final int REQUEST_EXPORT = 2;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    /** Установка, скачивание и экспорт идут по очереди; список грузится отдельно, чтобы их не ждать. */
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor();

    private static final class AppItem {
        String pkg;
        String label;
        String version;
        Drawable icon;
    }

    private interface Source {
        InputStream open() throws IOException;
    }

    private final List<AppItem> allApps = new ArrayList<>();
    private final List<AppItem> apps = new ArrayList<>(); // то, что видно с учётом поиска
    private final BaseAdapter adapter = new AppAdapter();

    private Ui ui;
    private TextView title, empty, appsTab, settingsTab, progressText;
    private ImageView plus;
    private ListView list;
    private ScrollView settingsScroll;
    private LinearLayout page, searchBar, settingsBox;
    private View headerLine;
    private EditText search;
    private Dialog sheet, message, progress;
    private PopupWindow menu;
    private SwipeRow openRow;
    private boolean onSettings;
    private boolean loaded;
    private boolean night, themeChanged;
    private int loadGeneration;
    private String exportPackage;

    // ---------- Жизненный цикл ----------

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        night = isNight(getResources().getConfiguration());
        ui = new Ui(this);
        setContentView(buildLayout());
        InstallReceiver.listener = this;
        if (state != null) exportPackage = state.getString("exportPackage");
        showTab(state != null && state.getBoolean("onSettings"));
        if (state == null) handleIntent(getIntent());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("exportPackage", exportPackage);
        out.putBoolean("onSettings", onSettings);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (menu != null) menu.dismiss();
        themeChanged = isNight(config) != night;
        applyThemeWhenIdle();
    }

    @Override
    protected void onDestroy() {
        if (InstallReceiver.listener == this) InstallReceiver.listener = null;
        hideProgress();
        if (menu != null) menu.dismiss();
        if (message != null) message.dismiss();
        dismissSheet();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        if (request == REQUEST_PICK) openUri(data.getData());
        else if (request == REQUEST_EXPORT) export(exportPackage, data.getData());
    }

    /** «Открыть в TrollStore» из файлового менеджера или «Поделиться». */
    @SuppressWarnings("deprecation")
    private void handleIntent(Intent intent) {
        // При открытии из «недавних» не предлагаем установить тот же файл повторно.
        if (intent == null || (intent.getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri != null) openUri(uri);
    }

    // ---------- Тема ----------

    private static boolean isNight(Configuration config) {
        return (config.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Новую тему применяем пересозданием экрана, но не посреди установки или открытого окна. */
    private void applyThemeWhenIdle() {
        page.post(() -> {
            if (!themeChanged || isFinishing() || isDestroyed()) return;
            if (progress != null || isShowing(sheet) || isShowing(message)) return;
            themeChanged = false;
            recreate();
        });
    }

    private static boolean isShowing(Dialog dialog) {
        return dialog != null && dialog.isShowing();
    }

    // ---------- Главный экран ----------

    @SuppressWarnings("deprecation")
    private View buildLayout() {
        page = ui.column();
        // Корень забирает фокус, чтобы клавиатура не выскакивала сама из-за поля поиска.
        page.setFocusableInTouchMode(true);

        // Маленький заголовок по центру, как в навигационной панели iOS.
        FrameLayout header = new FrameLayout(this);
        title = ui.text("", 17, ui.label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        header.addView(title, new FrameLayout.LayoutParams(MATCH, ui.dp(48)));
        plus = new ImageView(this);
        plus.setImageResource(R.drawable.ic_plus);
        plus.setScaleType(ImageView.ScaleType.CENTER);
        plus.setContentDescription("Установить приложение");
        plus.setOnClickListener(v -> {
            hideKeyboard();
            closeOpenRow();
            showAddMenu();
        });
        header.addView(plus, new FrameLayout.LayoutParams(ui.dp(52), ui.dp(48), Gravity.END));
        page.addView(header, ui.matchWrap());

        searchBar = buildSearchBar();
        LinearLayout.LayoutParams searchParams = ui.matchWrap();
        searchParams.setMargins(ui.dp(16), 0, ui.dp(16), ui.dp(14));
        page.addView(searchBar, searchParams);

        headerLine = ui.line(0);
        page.addView(headerLine);

        FrameLayout content = new FrameLayout(this);
        content.setBackgroundColor(ui.bg);

        list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setAdapter(adapter);
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int state) {
                if (state == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) closeOpenRow();
            }

            @Override
            public void onScroll(AbsListView view, int first, int visible, int total) {
            }
        });
        content.addView(list, new FrameLayout.LayoutParams(MATCH, MATCH));

        empty = ui.text("", 16, ui.secondary);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(ui.dp(40), 0, ui.dp(40), ui.dp(60));
        content.addView(empty, new FrameLayout.LayoutParams(MATCH, MATCH));

        settingsScroll = new ScrollView(this);
        settingsScroll.setBackgroundColor(ui.grouped);
        settingsBox = ui.column();
        settingsBox.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(32));
        settingsScroll.addView(settingsBox);
        content.addView(settingsScroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        page.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1));
        page.addView(ui.line(0));

        LinearLayout tabs = ui.row();
        tabs.setBackgroundColor(ui.bar);
        appsTab = tab("Приложения", R.drawable.ic_apps, false);
        settingsTab = tab("Настройки", R.drawable.ic_settings, true);
        tabs.addView(appsTab, new LinearLayout.LayoutParams(0, WRAP, 1));
        tabs.addView(settingsTab, new LinearLayout.LayoutParams(0, WRAP, 1));
        page.addView(tabs, ui.matchWrap());

        // На Android 15+ экран рисуется под системными панелями и клавиатурой — отступаем сами.
        page.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            int keyboard = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
                keyboard = insets.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top, right, keyboard);
            tabs.setPadding(0, 0, 0, bottom);
            tabs.setVisibility(keyboard > 0 ? View.GONE : View.VISIBLE);
            return insets;
        });
        return page;
    }

    private LinearLayout buildSearchBar() {
        LinearLayout bar = ui.row();
        bar.setBackground(ui.rounded(ui.field, 10));
        bar.setPadding(ui.dp(9), 0, ui.dp(9), 0);

        ImageView glass = new ImageView(this);
        glass.setImageResource(R.drawable.ic_search);
        bar.addView(glass, new LinearLayout.LayoutParams(ui.dp(18), ui.dp(18)));

        search = new EditText(this);
        search.setBackground(null);
        search.setHint("Поиск");
        search.setHintTextColor(ui.secondary);
        search.setTextColor(ui.label);
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        search.setPadding(ui.dp(7), 0, 0, 0);
        search.setOnEditorActionListener((view, action, event) -> {
            hideKeyboard();
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                applyFilter();
            }
        });
        bar.addView(search, new LinearLayout.LayoutParams(0, ui.dp(36), 1));
        return bar;
    }

    private void hideKeyboard() {
        if (search.getWindowToken() == null) return;
        InputMethodManager keyboard = getSystemService(InputMethodManager.class);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
    }

    private TextView tab(String text, int icon, boolean settings) {
        TextView tab = ui.text(text, 11, ui.secondary);
        tab.setGravity(Gravity.CENTER);
        tab.setPadding(0, ui.dp(7), 0, ui.dp(5));
        tab.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0);
        tab.setOnClickListener(v -> showTab(settings));
        return tab;
    }

    @SuppressWarnings("deprecation")
    private void showTab(boolean settings) {
        onSettings = settings;
        hideKeyboard();
        closeOpenRow();
        // У настроек панель сверху как у вкладок, у списка — цвета фона.
        int top = settings ? ui.bar : ui.bg;
        page.setBackgroundColor(top);
        getWindow().setStatusBarColor(top);
        title.setText(settings ? "Настройки" : "Приложения");
        plus.setVisibility(settings ? View.GONE : View.VISIBLE);
        searchBar.setVisibility(settings ? View.GONE : View.VISIBLE);
        headerLine.setVisibility(settings ? View.VISIBLE : View.GONE);
        list.setVisibility(settings ? View.GONE : View.VISIBLE);
        settingsScroll.setVisibility(settings ? View.VISIBLE : View.GONE);
        empty.setVisibility(View.GONE);
        highlight(appsTab, !settings);
        highlight(settingsTab, settings);
        refresh();
    }

    private void highlight(TextView tab, boolean active) {
        int color = active ? ui.tint : ui.secondary;
        tab.setTextColor(color);
        tab.setCompoundDrawableTintList(ColorStateList.valueOf(color));
    }

    private void refresh() {
        if (onSettings) buildSettings();
        else loadApps();
    }

    // ---------- Список приложений ----------

    private void loadApps() {
        boolean all = prefs().getBoolean("showAll", false);
        int generation = ++loadGeneration;
        int iconSize = ui.dp(60);
        int border = ui.iconBorder;
        Context app = getApplicationContext();
        LOADER.execute(() -> {
            List<AppItem> result = queryApps(app, all, iconSize, border);
            runOnUiThread(() -> {
                if (generation != loadGeneration || isDestroyed()) return;
                allApps.clear();
                allApps.addAll(result);
                loaded = true;
                applyFilter();
            });
        });
    }

    private void applyFilter() {
        String query = search.getText().toString().trim().toLowerCase(Locale.getDefault());
        apps.clear();
        for (AppItem item : allApps) {
            if (query.isEmpty() || item.label.toLowerCase(Locale.getDefault()).contains(query)
                    || item.pkg.toLowerCase(Locale.ROOT).contains(query)) {
                apps.add(item);
            }
        }
        openRow = null; // строки сейчас пересоздадутся закрытыми
        adapter.notifyDataSetChanged();
        if (!loaded) return;
        if (!query.isEmpty()) {
            empty.setText("Ничего не найдено");
        } else if (prefs().getBoolean("showAll", false)) {
            empty.setText("Сторонних приложений не найдено");
        } else {
            empty.setText("Здесь появятся приложения, установленные через TrollStore.\n\nНажми + и выбери .apk, .apks, .xapk или .apkm");
        }
        empty.setVisibility(!onSettings && apps.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private static List<AppItem> queryApps(Context context, boolean all, int iconSize, int border) {
        PackageManager pm = context.getPackageManager();
        String self = context.getPackageName();
        List<AppItem> result = new ArrayList<>();
        for (PackageInfo info : pm.getInstalledPackages(0)) {
            ApplicationInfo ai = info.applicationInfo;
            if (ai == null || self.equals(info.packageName)) continue;
            if (all) {
                if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            } else {
                if (!self.equals(installerOf(pm, info.packageName))) continue;
            }
            AppItem item = new AppItem();
            item.pkg = info.packageName;
            item.label = String.valueOf(ai.loadLabel(pm));
            item.version = info.versionName == null ? "?" : info.versionName;
            item.icon = Ui.roundIcon(context.getResources(), ai.loadIcon(pm), iconSize, border);
            result.add(item);
        }
        Collator collator = Collator.getInstance();
        result.sort((a, b) -> collator.compare(a.label, b.label));
        return result;
    }

    @SuppressWarnings("deprecation")
    private static String installerOf(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) return pm.getInstallSourceInfo(pkg).getInstallingPackageName();
            return pm.getInstallerPackageName(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public Object getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View recycled, ViewGroup parent) {
            AppItem item = apps.get(position);
            LinearLayout cell = ui.column();
            cell.setBackground(ui.pressable(ui.bg, 0));
            cell.addView(ui.appRow(item.icon, item.label, item.version + " • " + item.pkg), ui.matchWrap());
            cell.addView(ui.line(0));

            TextView delete = ui.text("Удалить", 16, Color.WHITE);
            delete.setGravity(Gravity.CENTER);
            delete.setBackgroundColor(ui.red);
            SwipeRow row = new SwipeRow(MainActivity.this, cell, delete, ui.dp(84), swiped -> {
                if (openRow != null && openRow != swiped) openRow.close();
                openRow = swiped;
            });
            delete.setOnClickListener(v -> {
                closeOpenRow();
                uninstall(item.pkg);
            });
            cell.setOnClickListener(v -> {
                hideKeyboard();
                if (closeOpenRow()) return; // первое касание только прячет «Удалить», как в iOS
                showAppSheet(item);
            });
            return row;
        }
    }

    /** Возвращает true, если какая-то строка действительно была сдвинута. */
    private boolean closeOpenRow() {
        if (openRow == null) return false;
        boolean wasOpen = openRow.isOpen();
        openRow.close();
        openRow = null;
        return wasOpen;
    }

    // ---------- Меню ----------

    /** Выпадающее меню под «+», как в iOS. */
    private void showAddMenu() {
        LinearLayout box = ui.column();
        box.setBackground(ui.rounded(ui.sheet, 13));
        box.setClipToOutline(true);
        PopupWindow popup = new PopupWindow(box, ui.dp(256), WRAP, true);
        popup.setBackgroundDrawable(ui.rounded(ui.sheet, 13));
        popup.setElevation(ui.dp(16));
        popup.setOutsideTouchable(true);
        box.addView(menuRow(popup, "Установить из файла", R.drawable.ic_file_add, this::pickFile));
        box.addView(ui.line(0));
        box.addView(menuRow(popup, "Установить по ссылке", R.drawable.ic_link_add, this::askUrl));
        popup.setOnDismissListener(() -> {
            plus.setAlpha(1f);
            menu = null;
        });
        plus.setAlpha(0.35f);
        menu = popup;
        popup.showAsDropDown(plus, -ui.dp(8), 0, Gravity.END);
    }

    private View menuRow(PopupWindow popup, String text, int icon, Runnable action) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8));
        row.setMinimumHeight(ui.dp(48));
        row.setBackground(ui.pressable(ui.sheet, 0));
        row.addView(ui.text(text, 16, ui.label), new LinearLayout.LayoutParams(0, WRAP, 1));
        ImageView image = new ImageView(this);
        image.setImageResource(icon);
        row.addView(image, new LinearLayout.LayoutParams(ui.dp(22), ui.dp(22)));
        row.setOnClickListener(v -> {
            popup.dismiss();
            action.run();
        });
        row.setLayoutParams(ui.matchWrap());
        return row;
    }

    private Dialog newDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setOnDismissListener(closed -> applyThemeWhenIdle());
        return dialog;
    }

    private void dismissSheet() {
        if (sheet != null) sheet.dismiss();
    }

    /** Меню снизу в духе iOS action sheet: панель с действиями и отдельная «Отмена». */
    private void showSheet(LinearLayout panel) {
        if (isFinishing() || isDestroyed()) return;
        dismissSheet();
        Dialog dialog = newDialog();

        LinearLayout box = ui.column();
        box.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(ui.rounded(ui.sheet, 14));
        scroll.setClipToOutline(true);
        scroll.addView(panel);
        box.addView(scroll, new LinearLayout.LayoutParams(MATCH, WRAP, 1));

        TextView cancel = ui.button("Отмена", 19, ui.tint, ui.card, 56);
        cancel.setTypeface(Typeface.DEFAULT_BOLD);
        cancel.setBackground(ui.pressable(ui.card, 14));
        cancel.setOnClickListener(v -> dialog.dismiss());
        LinearLayout.LayoutParams params = ui.matchWrap();
        params.topMargin = ui.dp(8);
        box.addView(cancel, params);

        dialog.setContentView(box);
        Window window = dialog.getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(MATCH, WRAP);
        window.setDimAmount(0.35f);
        window.setWindowAnimations(android.R.style.Animation_InputMethod); // выезжает снизу
        sheet = dialog;
        dialog.show();
    }

    private void addAction(LinearLayout panel, String text, int color, Runnable action) {
        panel.addView(ui.line(0));
        TextView button = ui.button(text, 19, color, ui.sheet, 56);
        button.setOnClickListener(v -> {
            dismissSheet();
            action.run();
        });
        panel.addView(button, ui.matchWrap());
    }

    private void showAppSheet(AppItem item) {
        LinearLayout panel = ui.column();
        TextView name = ui.text(item.label, 13, ui.secondary);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.CENTER);
        name.setPadding(ui.dp(16), ui.dp(15), ui.dp(16), ui.dp(4));
        panel.addView(name, ui.matchWrap());
        TextView pkg = ui.text(item.pkg, 13, ui.secondary);
        pkg.setGravity(Gravity.CENTER);
        pkg.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(15));
        panel.addView(pkg, ui.matchWrap());

        addAction(panel, "Открыть", ui.tint, () -> openApp(item.pkg));
        addAction(panel, "Подробности", ui.tint, () -> showDetails(item));
        addAction(panel, "Настройки в системе", ui.tint, () -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", item.pkg, null))));
        addAction(panel, "Сохранить APK", ui.tint, () -> pickExportTarget(item));
        addAction(panel, "Удалить приложение", ui.red, () -> uninstall(item.pkg));
        showSheet(panel);
    }

    // ---------- Окно о приложении ----------

    /** Карточка с разделами и кнопками внизу, как «Show Details» и подтверждение установки. */
    private void showCard(Drawable icon, String name, List<AppReport.Section> sections,
                          String confirm, Runnable onConfirm) {
        if (isFinishing() || isDestroyed()) return;
        dismissSheet();
        Dialog dialog = newDialog();

        LinearLayout head = ui.row();
        head.setGravity(Gravity.CENTER);
        head.setPadding(ui.dp(16), ui.dp(18), ui.dp(16), ui.dp(2));
        if (icon != null) {
            ImageView image = new ImageView(this);
            image.setImageDrawable(icon);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ui.dp(30), ui.dp(30));
            params.rightMargin = ui.dp(8);
            head.addView(image, params);
        }
        TextView heading = ui.text(name, 18, ui.label);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setGravity(Gravity.CENTER);
        head.addView(heading);

        LinearLayout body = ui.column();
        body.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(16));
        for (AppReport.Section section : sections) {
            TextView subheading = ui.text(section.title, 15, ui.label);
            subheading.setTypeface(Typeface.DEFAULT_BOLD);
            subheading.setPadding(0, ui.dp(12), 0, ui.dp(2));
            body.addView(subheading);
            for (AppReport.Line line : section.lines) {
                int color = line.level == AppReport.DANGER ? ui.red
                        : line.level == AppReport.WARNING ? ui.orange : ui.label;
                body.addView(ui.text(line.text, 13, color));
            }
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);

        LinearLayout buttons = ui.row();
        TextView close = ui.button(confirm == null ? "Закрыть" : "Отмена", 17, ui.tint, ui.alert, 46);
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(0, WRAP, 1));
        if (confirm != null) {
            close.setTypeface(Typeface.DEFAULT_BOLD);
            buttons.addView(ui.verticalLine());
            TextView ok = ui.button(confirm, 17, ui.tint, ui.alert, 46);
            ok.setOnClickListener(v -> onConfirm.run());
            buttons.addView(ok, new LinearLayout.LayoutParams(0, WRAP, 1));
        }

        LinearLayout card = ui.column();
        card.setBackground(ui.rounded(ui.alert, 14));
        card.setClipToOutline(true);
        card.addView(head, ui.matchWrap());
        card.addView(scroll, new LinearLayout.LayoutParams(MATCH, WRAP, 1));
        card.addView(ui.line(0));
        card.addView(buttons, ui.matchWrap());

        FrameLayout frame = new FrameLayout(this); // поля сверху и снизу для длинного списка
        frame.setPadding(0, ui.dp(24), 0, ui.dp(24));
        frame.addView(card, new FrameLayout.LayoutParams(MATCH, WRAP));
        sheet = dialog;
        present(dialog, frame, 296);
    }

    private void showDetails(AppItem item) {
        PackageManager pm = getPackageManager();
        PackageInfo info;
        try {
            info = packageDetails(pm, item.pkg);
        } catch (PackageManager.NameNotFoundException e) {
            toast("Приложение уже удалено");
            return;
        }
        ApplicationInfo ai = info.applicationInfo;
        long size = new File(ai.sourceDir).length();
        if (ai.splitSourceDirs != null) {
            for (String path : ai.splitSourceDirs) size += new File(path).length();
        }

        List<AppReport.Section> sections = new ArrayList<>();
        sections.add(metadata(item.pkg, item.version, size, ai.minSdkVersion, ai.targetSdkVersion));
        List<String> requested = new ArrayList<>();
        if (info.requestedPermissions != null) requested.addAll(Arrays.asList(info.requestedPermissions));
        sections.addAll(AppReport.build(requested, ApkBundle.guards(info), ai.targetSdkVersion));
        showCard(null, item.label, sections, null, null);
    }

    private static PackageInfo packageDetails(PackageManager pm, String pkg)
            throws PackageManager.NameNotFoundException {
        try {
            return pm.getPackageInfo(pkg, ApkBundle.INFO_FLAGS);
        } catch (RuntimeException e) {
            // У очень больших приложений полный список не пролезает в ответ системы.
            return pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS);
        }
    }

    private AppReport.Section metadata(String pkg, String version, long size, int minSdk, int targetSdk) {
        return new AppReport.Section("Метаданные")
                .add("ID пакета: " + pkg, AppReport.PLAIN)
                .add("Версия: " + version, AppReport.PLAIN)
                .add("Размер: " + formatSize(size), AppReport.PLAIN)
                .add("API: минимум " + minSdk + ", целевой " + targetSdk, AppReport.PLAIN);
    }

    private void showInstallCard(ApkBundle bundle) {
        AppReport.Section meta = metadata(
                bundle.packageName, bundle.versionName, bundle.size, bundle.minSdk, bundle.targetSdk);
        if (bundle.apks.size() > 1) meta.add("Частей APK: " + bundle.apks.size(), AppReport.PLAIN);
        addInstallKind(meta, bundle);
        if (bundle.obbCount > 0) {
            meta.add("В архиве есть OBB-файлы. Они не копируются: игра может не запуститься "
                    + "или начать докачку.", AppReport.WARNING);
        }
        List<AppReport.Section> sections = new ArrayList<>();
        sections.add(meta);
        sections.addAll(AppReport.build(bundle.permissions, bundle.guards, bundle.targetSdk));
        Drawable icon = Ui.roundIcon(getResources(), bundle.icon, ui.dp(30), ui.iconBorder);
        showCard(icon, bundle.label, sections, "Установить", () -> startInstall(bundle));
    }

    private void addInstallKind(AppReport.Section meta, ApkBundle bundle) {
        try {
            PackageInfo old = getPackageManager().getPackageInfo(bundle.packageName, 0);
            long oldCode = ApkBundle.versionCode(old);
            if (bundle.versionCode > oldCode) {
                meta.add("Это обновление с версии " + old.versionName, AppReport.PLAIN);
            } else if (bundle.versionCode == oldCode) {
                meta.add("Это переустановка той же версии", AppReport.PLAIN);
            } else {
                meta.add("Это откат на старую версию: Android не даст, сначала удали новую.", AppReport.DANGER);
            }
        } catch (PackageManager.NameNotFoundException e) {
            meta.add("Новая установка", AppReport.PLAIN);
        }
    }

    // ---------- Открытие файла и установка ----------

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_PICK);
    }

    private void askUrl() {
        EditText input = new EditText(this);
        input.setHint("https://…/app.apk");
        input.setHintTextColor(ui.secondary);
        input.setTextColor(ui.label);
        input.setTextSize(15);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        GradientDrawable field = ui.rounded(ui.card, 7);
        field.setStroke(Math.max(1, ui.dp(0.5f)), ui.separator);
        input.setBackground(field);
        input.setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(8));
        Dialog dialog = iosAlert("Установить по ссылке", null, input,
                "Отмена", "Установить", () -> download(input.getText().toString().trim()));
        if (dialog == null) return;
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        input.requestFocus();
    }

    private void download(String address) {
        if (!address.startsWith("https://")) {
            alert("Нужна другая ссылка", "Поддерживаются только прямые ссылки https://");
            return;
        }
        load("Скачиваю…", () -> {
            HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            int code = connection.getResponseCode();
            if (code != HttpURLConnection.HTTP_OK) throw new IOException("Сервер ответил кодом " + code);
            return connection.getInputStream();
        });
    }

    private void openUri(Uri uri) {
        load("Читаю файл…", () -> getContentResolver().openInputStream(uri));
    }

    private void load(String text, Source source) {
        dismissSheet();
        showProgress(text);
        Context app = getApplicationContext();
        IO.execute(() -> {
            try (InputStream in = source.open()) {
                if (in == null) throw new IOException("Не удалось открыть файл");
                ApkBundle bundle = ApkBundle.load(app, in, bytes ->
                        runOnUiThread(() -> updateProgress(text + " " + formatSize(bytes))));
                runOnUiThread(() -> {
                    hideProgress();
                    showInstallCard(bundle);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideProgress();
                    alert("Не получилось открыть", describe(e));
                });
            }
        });
    }

    private void startInstall(ApkBundle bundle) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            iosAlert("Нужно разрешение",
                    "Разреши TrollStore устанавливать приложения, вернись сюда и нажми «Установить» ещё раз.",
                    null, "Отмена", "Настройки", this::openInstallPermission);
            return;
        }
        dismissSheet();
        showProgress("Устанавливаю…");
        Context app = getApplicationContext();
        IO.execute(() -> {
            try {
                Installer.install(app, bundle);
                bundle.delete();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideProgress();
                    alert("Не получилось установить", describe(e));
                });
            }
        });
    }

    @Override
    public void onConfirmationNeeded() {
        hideProgress();
    }

    @Override
    public void onInstallFinished(boolean success, String details) {
        hideProgress();
        if (success) toast("Установлено ✓");
        else alert("Не установилось", details);
        refresh();
    }

    // ---------- Действия с приложением ----------

    private void openApp(String pkg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) toast("У этого приложения нет экрана запуска");
        else startActivity(launch);
    }

    private void uninstall(String pkg) {
        startActivity(new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", pkg, null)));
    }

    private void pickExportTarget(AppItem item) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(item.pkg, 0);
            boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
            exportPackage = item.pkg;
            String name = (item.label + "_" + item.version).replaceAll("[\\\\/:*?\"<>|]", "_");
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/octet-stream");
            intent.putExtra(Intent.EXTRA_TITLE, name + (split ? ".apks" : ".apk"));
            startActivityForResult(intent, REQUEST_EXPORT);
        } catch (PackageManager.NameNotFoundException e) {
            toast("Приложение уже удалено");
        }
    }

    private void export(String pkg, Uri target) {
        if (pkg == null) return;
        showProgress("Сохраняю…");
        Context app = getApplicationContext();
        IO.execute(() -> {
            String error = null;
            try (OutputStream out = app.getContentResolver().openOutputStream(target)) {
                if (out == null) throw new IOException("Не удалось открыть файл для записи");
                ApkBundle.export(app, pkg, out);
            } catch (Exception e) {
                error = describe(e);
            }
            String result = error;
            runOnUiThread(() -> {
                hideProgress();
                if (result == null) toast("Сохранено ✓");
                else alert("Не получилось сохранить", result);
            });
        });
    }

    // ---------- Настройки ----------

    private void buildSettings() {
        settingsBox.removeAllViews();

        LinearLayout install = addGroup("УСТАНОВКА");
        if (getPackageManager().canRequestPackageInstalls()) {
            ui.addRow(install, ui.groupRow("Установка приложений: разрешена", ui.secondary));
        } else {
            TextView allow = ui.groupRow("Разрешить установку приложений", ui.tint);
            allow.setOnClickListener(v -> openInstallPermission());
            ui.addRow(install, allow);
        }
        settingsBox.addView(ui.footer("Без этого разрешения Android не даст TrollStore ставить приложения."));

        LinearLayout utilities = addGroup("УТИЛИТЫ");
        TextView clear = ui.groupRow("Очистить временные файлы", ui.tint);
        clear.setOnClickListener(v -> {
            ApkBundle.clearCache(this);
            buildSettings();
        });
        ui.addRow(utilities, clear);
        settingsBox.addView(ui.footer("Временные файлы занимают " + formatSize(ApkBundle.cacheSize(this)) + "."));

        LinearLayout listGroup = addGroup("СПИСОК");
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(16), ui.dp(8), ui.dp(12), ui.dp(8));
        row.addView(ui.text("Все сторонние приложения", 17, ui.label), new LinearLayout.LayoutParams(0, WRAP, 1));
        IosSwitch showAll = new IosSwitch(this, ui, prefs().getBoolean("showAll", false),
                checked -> prefs().edit().putBoolean("showAll", checked).apply());
        showAll.setContentDescription("Все сторонние приложения");
        row.addView(showAll);
        row.setOnClickListener(v -> showAll.performClick());
        ui.addRow(listGroup, row);
        settingsBox.addView(ui.footer("Если выключено, в списке только то, что установлено через TrollStore."));

        LinearLayout last = addGroup("");
        TextView remove = ui.groupRow("Удалить TrollStore", ui.red);
        remove.setGravity(Gravity.CENTER);
        remove.setOnClickListener(v -> uninstall(getPackageName()));
        ui.addRow(last, remove);
        settingsBox.addView(ui.footer("TrollStore " + ownVersion() + " для Android\n\n"
                + "Неофициальный проект: не связан с TrollStore для iOS и его автором (opa334).\n\n"
                + "Приложения ставятся штатным установщиком Android. Без root и эксплойтов."));
    }

    private LinearLayout addGroup(String heading) {
        settingsBox.addView(ui.header(heading));
        LinearLayout group = ui.group();
        settingsBox.addView(group, ui.matchWrap());
        return group;
    }

    private String ownVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "?";
        }
    }

    private void openInstallPermission() {
        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.fromParts("package", getPackageName(), null)));
    }

    // ---------- Мелочи ----------

    private SharedPreferences prefs() {
        return getSharedPreferences("settings", MODE_PRIVATE);
    }

    private void showProgress(String text) {
        if (isFinishing() || isDestroyed()) return;
        hideProgress();
        LinearLayout box = ui.column();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(24), ui.dp(22), ui.dp(24), ui.dp(20));
        box.setBackground(ui.rounded(ui.alert, 14));
        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(ui.secondary));
        box.addView(spinner, new LinearLayout.LayoutParams(ui.dp(36), ui.dp(36)));
        progressText = ui.text(text, 15, ui.label);
        progressText.setGravity(Gravity.CENTER);
        progressText.setPadding(0, ui.dp(12), 0, 0);
        box.addView(progressText, ui.matchWrap());

        progress = newDialog();
        progress.setCancelable(false);
        present(progress, box, 270);
    }

    private void updateProgress(String text) {
        if (progressText != null) progressText.setText(text);
    }

    private void hideProgress() {
        if (progress != null) progress.dismiss();
        progress = null;
    }

    private void alert(String heading, String text) {
        iosAlert(heading, text, null, null, "OK", null);
    }

    /** Окно в духе iOS: заголовок, текст и кнопки в ряд. Возвращает null, если экран уже закрыт. */
    private Dialog iosAlert(String heading, String text, View extra, String cancel, String ok, Runnable action) {
        if (isFinishing() || isDestroyed()) return null;
        Dialog dialog = newDialog();

        LinearLayout texts = ui.column();
        texts.setPadding(ui.dp(16), ui.dp(19), ui.dp(16), ui.dp(17));
        TextView head = ui.text(heading, 17, ui.label);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        head.setGravity(Gravity.CENTER);
        texts.addView(head, ui.matchWrap());
        if (text != null) {
            TextView body = ui.text(text, 13, ui.label);
            body.setGravity(Gravity.CENTER);
            body.setPadding(0, ui.dp(6), 0, 0);
            texts.addView(body, ui.matchWrap());
        }
        if (extra != null) {
            LinearLayout.LayoutParams params = ui.matchWrap();
            params.topMargin = ui.dp(14);
            texts.addView(extra, params);
        }

        LinearLayout box = ui.column();
        box.setBackground(ui.rounded(ui.alert, 14));
        box.setClipToOutline(true);
        ScrollView scroll = new ScrollView(this); // длинный текст ошибки должен прокручиваться
        scroll.addView(texts);
        box.addView(scroll, new LinearLayout.LayoutParams(MATCH, WRAP, 1));
        box.addView(ui.line(0));

        // Как в iOS: жирным выделена «Отмена», а если кнопка одна — то она.
        LinearLayout buttons = ui.row();
        if (cancel != null) {
            TextView no = ui.button(cancel, 17, ui.tint, ui.alert, 46);
            no.setTypeface(Typeface.DEFAULT_BOLD);
            no.setOnClickListener(v -> dialog.dismiss());
            buttons.addView(no, new LinearLayout.LayoutParams(0, WRAP, 1));
            buttons.addView(ui.verticalLine());
        }
        TextView yes = ui.button(ok, 17, ui.tint, ui.alert, 46);
        if (cancel == null) yes.setTypeface(Typeface.DEFAULT_BOLD);
        yes.setOnClickListener(v -> {
            dialog.dismiss();
            if (action != null) action.run();
        });
        buttons.addView(yes, new LinearLayout.LayoutParams(0, WRAP, 1));
        box.addView(buttons, ui.matchWrap());

        message = dialog;
        present(dialog, box, 280);
        return dialog;
    }

    private void present(Dialog dialog, View content, int width) {
        dialog.setContentView(content);
        Window window = dialog.getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(ui.dp(width), WRAP);
        window.setDimAmount(0.35f);
        dialog.show();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private String formatSize(long bytes) {
        return Formatter.formatShortFileSize(this, bytes);
    }

    private static String describe(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
    }
}
