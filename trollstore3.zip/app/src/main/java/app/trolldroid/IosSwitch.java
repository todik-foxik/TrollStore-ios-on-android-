package app.trolldroid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Switch;

/** Переключатель как в iOS: зелёная дорожка и белый кружок. */
final class IosSwitch extends View {
    interface Listener {
        void onChange(boolean checked);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Ui ui;
    private boolean checked;

    IosSwitch(Context context, Ui ui, boolean initial, Listener listener) {
        super(context);
        this.ui = ui;
        this.checked = initial;
        setOnClickListener(view -> {
            checked = !checked;
            invalidate();
            listener.onChange(checked);
        });
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension(ui.dp(51), ui.dp(31));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float width = getWidth();
        float half = getHeight() / 2f;
        paint.setColor(checked ? ui.green : ui.off);
        canvas.drawRoundRect(0, 0, width, half * 2, half, half, paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(checked ? width - half : half, half, half - ui.dp(2), paint);
    }

    // Чтобы экранный диктор видел обычный переключатель.
    @Override
    public CharSequence getAccessibilityClassName() {
        return Switch.class.getName();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setCheckable(true);
        info.setChecked(checked);
    }
}
