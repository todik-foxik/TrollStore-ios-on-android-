package app.trolldroid;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Установка через сессию PackageInstaller: она умеет и одиночный APK, и набор частей. */
final class Installer {
    static void install(Context context, ApkBundle bundle) throws IOException {
        PackageInstaller installer = context.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params =
                new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(bundle.packageName);
        params.setSize(bundle.size);
        if (Build.VERSION.SDK_INT >= 31) {
            // Просим не спрашивать подтверждение; система согласится только для части обновлений.
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        }

        int id = installer.createSession(params);
        boolean committed = false;
        try (PackageInstaller.Session session = installer.openSession(id)) {
            for (File apk : bundle.apks) {
                try (InputStream in = new FileInputStream(apk);
                     OutputStream out = session.openWrite(apk.getName(), 0, apk.length())) {
                    ApkBundle.copy(in, out, null);
                    session.fsync(out);
                }
            }
            Intent result = new Intent(context, InstallReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            // Изменяемый: система дописывает в intent результат установки.
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            session.commit(PendingIntent.getBroadcast(context, id, result, flags).getIntentSender());
            committed = true;
        } finally {
            if (!committed) installer.abandonSession(id);
        }
    }
}
