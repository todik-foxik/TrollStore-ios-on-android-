package com.mygallery.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Media {
    long id, date, size;
    int width, height;
    String name, album;
    boolean favorite;
    Uri uri;
}

final class Library {
    static final int BLUE = 0xFF0A84FF, GRAY = 0xFF8E8E93, CARD = 0xFF1C1C1E;
    static final Handler UI = new Handler(Looper.getMainLooper());
    static final ExecutorService IO = Executors.newFixedThreadPool(4);
    static List<Media> viewing = new ArrayList<>();

    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8 / 1024)) {
                @Override protected int sizeOf(String key, Bitmap b) { return b.getByteCount() / 1024; }
            };

    static List<Media> load(Context c, boolean trashed) {
        List<Media> out = new ArrayList<>();
        String[] cols = {"_id", "_display_name", "bucket_display_name", "datetaken", "date_added",
                "width", "height", "_size", "is_favorite"};
        Bundle args = new Bundle();
        args.putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, trashed ? MediaStore.MATCH_ONLY : MediaStore.MATCH_EXCLUDE);
        Uri base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        try (Cursor r = c.getContentResolver().query(base, cols, args, null)) {
            while (r != null && r.moveToNext()) {
                Media m = new Media();
                m.id = r.getLong(0);
                m.name = String.valueOf(r.getString(1));
                m.album = r.getString(2) == null ? "Другое" : r.getString(2);
                m.date = r.getLong(3) > 0 ? r.getLong(3) : r.getLong(4) * 1000;
                m.width = r.getInt(5);
                m.height = r.getInt(6);
                m.size = r.getLong(7);
                m.favorite = r.getInt(8) == 1;
                m.uri = ContentUris.withAppendedId(base, m.id);
                out.add(m);
            }
        }
        out.sort((a, b) -> Long.compare(b.date, a.date));
        return out;
    }

    static void thumb(ImageView view, Media m, int px) {
        String key = m.id + ":" + m.size + ":" + px;
        view.setTag(key);
        Bitmap cached = CACHE.get(key);
        view.setImageBitmap(cached);
        if (cached != null) return;
        Context c = view.getContext().getApplicationContext();
        IO.execute(() -> {
            try {
                Bitmap b = c.getContentResolver().loadThumbnail(m.uri, new Size(px, px), null);
                CACHE.put(key, b);
                UI.post(() -> { if (key.equals(view.getTag())) view.setImageBitmap(b); });
            } catch (Exception ignored) { }
        });
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    static GradientDrawable rounded(Context c, int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radius));
        return g;
    }

    static SimpleDateFormat formatter(String pattern) {
        return new SimpleDateFormat(pattern, Locale.forLanguageTag("ru"));
    }

    static String date(long time, String pattern) { return formatter(pattern).format(new Date(time)); }

    static ArrayList<Uri> uris(List<Media> list) {
        ArrayList<Uri> out = new ArrayList<>();
        for (Media m : list) out.add(m.uri);
        return out;
    }

    static void share(Activity a, List<Media> list) {
        if (list.isEmpty()) return;
        ArrayList<Uri> u = uris(list);
        Intent i = new Intent(u.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
        i.setType("image/*");
        if (u.size() == 1) i.putExtra(Intent.EXTRA_STREAM, u.get(0));
        else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, u);
        ClipData clip = ClipData.newRawUri("", u.get(0));
        for (int n = 1; n < u.size(); n++) clip.addItem(new ClipData.Item(u.get(n)));
        i.setClipData(clip);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(Intent.createChooser(i, "Поделиться"));
    }

    static void ask(Activity a, PendingIntent p, int code) {
        try {
            a.startIntentSenderForResult(p.getIntentSender(), code, null, 0, 0, 0);
        } catch (IntentSender.SendIntentException ignored) { }
    }

    interface Body { void write(OutputStream out) throws IOException; }

    static void save(Context c, String folder, String name, String mime, Body body) throws IOException {
        ContentResolver r = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/" + folder);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("insert");
        try (OutputStream out = r.openOutputStream(uri)) {
            body.write(out);
        } catch (Exception e) {
            r.delete(uri, null, null);
            throw new IOException(e);
        }
        v.clear();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        r.update(uri, v, null, null);
    }

    static void copy(Context c, Media m, String folder) {
        IO.execute(() -> {
            String message;
            try {
                String mime = c.getContentResolver().getType(m.uri);
                save(c, folder, m.name, mime == null ? "image/jpeg" : mime, out -> {
                    try (InputStream in = c.getContentResolver().openInputStream(m.uri)) {
                        byte[] buffer = new byte[65536];
                        for (int n; (n = in.read(buffer)) > 0; ) out.write(buffer, 0, n);
                    }
                });
                message = "Копия в альбоме " + folder;
            } catch (Exception e) {
                message = "Не получилось сохранить";
            }
            String result = message;
            UI.post(() -> Toast.makeText(c, result, Toast.LENGTH_SHORT).show());
        });
    }
}
