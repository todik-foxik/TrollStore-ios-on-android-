package com.mygallery.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.RecordingCanvas;
import android.graphics.RenderEffect;
import android.graphics.RenderNode;
import android.graphics.Shader;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.List;

/** Content that glass panels can blur. */
class Backdrop extends FrameLayout {
    final RenderNode node = new RenderNode("backdrop");

    final List<View> panels = new ArrayList<>();

    Backdrop(Context c) { super(c); }

    @Override public void onDescendantInvalidated(View child, View target) {
        super.onDescendantInvalidated(child, target);
        for (View panel : panels) panel.invalidate();
    }

    @Override protected void dispatchDraw(Canvas canvas) {
        if (Build.VERSION.SDK_INT < 31 || !canvas.isHardwareAccelerated()) {
            super.dispatchDraw(canvas);
            return;
        }
        node.setPosition(0, 0, getWidth(), getHeight());
        RecordingCanvas recording = node.beginRecording();
        super.dispatchDraw(recording);
        node.endRecording();
        canvas.drawRenderNode(node);
    }
}

/** Translucent panel with real blur on Android 12+. Must not be inside its Backdrop. */
class Glass extends FrameLayout {
    private final Backdrop backdrop;
    private final int tint;
    private final RenderNode blur = new RenderNode("blur");
    private final int[] mine = new int[2], theirs = new int[2];

    Glass(Context c, Backdrop backdrop, int tint) {
        super(c);
        this.backdrop = backdrop;
        this.tint = tint;
        setWillNotDraw(false);
        setClickable(true);
    }

    Glass round(int radiusDp, boolean topOnly) {
        float radius = Library.dp(getContext(), radiusDp);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                int extra = topOnly ? (int) radius : 0;
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight() + extra, radius);
            }
        });
        setClipToOutline(true);
        return this;
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        backdrop.panels.add(this);
    }

    @Override protected void onDetachedFromWindow() {
        backdrop.panels.remove(this);
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas canvas) {
        if (Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated() && getWidth() > 0 && getHeight() > 0) {
            getLocationInWindow(mine);
            backdrop.getLocationInWindow(theirs);
            blur.setPosition(0, 0, getWidth(), getHeight());
            blur.setRenderEffect(RenderEffect.createBlurEffect(60, 60, Shader.TileMode.CLAMP));
            RecordingCanvas recording = blur.beginRecording();
            recording.drawColor(Color.BLACK);
            recording.translate(theirs[0] - mine[0], theirs[1] - mine[1]);
            recording.drawRenderNode(backdrop.node);
            blur.endRecording();
            canvas.drawRenderNode(blur);
            canvas.drawColor(tint);
        } else {
            canvas.drawColor(tint | 0xF0000000);
        }
    }
}

final class Motion {
    static void edgeToEdge(Activity activity) {
        Window window = activity.getWindow();
        window.setDecorFitsSystemWindows(false);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.setNavigationBarContrastEnforced(false);
    }

    static void press(View view) {
        view.setOnTouchListener((v, event) -> {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).setInterpolator(new DecelerateInterpolator());
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1).scaleY(1).setDuration(350).setInterpolator(new OvershootInterpolator(3));
            }
            return false;
        });
    }

    static void pop(View view) {
        view.setScaleX(0.6f);
        view.setScaleY(0.6f);
        view.animate().scaleX(1).scaleY(1).setDuration(350).setInterpolator(new OvershootInterpolator(3));
    }
}
