package com.mygallery.app;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.function.IntConsumer;
import static com.mygallery.app.Library.*;

public class EditActivity extends Activity {
    private Bitmap original, base;
    private ImageView image;
    private LinearLayout panel, tabs;
    private TextView done;
    private float brightness, contrast = 1, saturation = 1;
    private int filter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        FrameLayout top = new FrameLayout(this);
        TextView cancel = text(this, "Отмена", 17, Color.WHITE);
        cancel.setPadding(dp(this, 18), 0, dp(this, 18), 0);
        cancel.setOnClickListener(v -> finish());
        done = text(this, "Готово", 17, 0xFFFFD60A);
        done.setPadding(dp(this, 18), 0, dp(this, 18), 0);
        done.setOnClickListener(v -> saveCopy());
        top.addView(cancel, new FrameLayout.LayoutParams(-2, -1, Gravity.START));
        top.addView(done, new FrameLayout.LayoutParams(-2, -1, Gravity.END));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(this, 52)));

        image = new ImageView(this);
        root.addView(image, new LinearLayout.LayoutParams(-1, 0, 1));
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(this, 12), dp(this, 8), dp(this, 12), 0);
        root.addView(panel, new LinearLayout.LayoutParams(-1, dp(this, 170)));

        tabs = new LinearLayout(this);
        String[] names = {"Коррекция", "Фильтры", "Обрезка"};
        for (int i = 0; i < names.length; i++) {
            final int n = i;
            TextView tab = text(this, names[i], 12, GRAY);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0, dp(this, 6), 0, 0);
            int[] icons = {R.drawable.ic_adjust, R.drawable.ic_filters, R.drawable.ic_crop};
            tab.setCompoundDrawablesWithIntrinsicBounds(0, icons[i], 0, 0);
            Motion.press(tab);
            tab.setOnClickListener(v -> showTab(n));
            tabs.addView(tab, new LinearLayout.LayoutParams(0, -1, 1));
        }
        root.addView(tabs, new LinearLayout.LayoutParams(-1, dp(this, 56)));
        setContentView(root);
        showTab(0);

        Uri uri = getIntent().getData();
        IO.execute(() -> {
            try {
                Bitmap bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), uri),
                        (decoder, info, source) -> {
                            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                            int max = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                            decoder.setTargetSampleSize(Math.max(1, (int) Math.ceil(max / 4096.0)));
                        });
                UI.post(() -> {
                    original = bitmap;
                    base = bitmap;
                    refresh();
                });
            } catch (Exception e) {
                UI.post(() -> finish());
            }
        });
    }

    private void showTab(int selected) {
        panel.removeAllViews();
        panel.setAlpha(0);
        panel.animate().alpha(1).setDuration(220);
        for (int i = 0; i < 3; i++) {
            TextView tab = (TextView) tabs.getChildAt(i);
            int color = i == selected ? Color.WHITE : GRAY;
            tab.setTextColor(color);
            tab.setCompoundDrawableTintList(ColorStateList.valueOf(color));
        }
        if (selected == 0) {
            chips(new String[]{"✦ Авто"}, i -> auto());
            slider("Экспозиция", Math.round(brightness / 1.6f) + 50, p -> brightness = (p - 50) * 1.6f);
            slider("Контраст", Math.round((contrast - 0.5f) * 100), p -> contrast = 0.5f + p / 100f);
            slider("Насыщенность", Math.round(saturation * 50), p -> saturation = p / 50f);
        } else if (selected == 1) {
            chips(new String[]{"Оригинал", "Ч/Б", "Тёплый", "Холодный", "Сепия", "Яркий"}, i -> filter = i);
        } else {
            chips(new String[]{"↻ Повернуть", "⇋ Отразить", "1:1", "4:3", "16:9", "Сброс"}, i -> geometry(i));
        }
    }

    private void slider(String name, int progress, IntConsumer change) {
        panel.addView(text(this, name, 12, GRAY));
        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(progress);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) {
                    change.accept(p);
                    refresh();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        panel.addView(seek);
    }

    private void chips(String[] names, IntConsumer click) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < names.length; i++) {
            final int n = i;
            TextView chip = text(this, names[i], 14, Color.WHITE);
            chip.setBackground(rounded(this, CARD, 18));
            chip.setPadding(dp(this, 14), dp(this, 7), dp(this, 14), dp(this, 7));
            chip.setOnClickListener(v -> {
                click.accept(n);
                refresh();
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.setMargins(dp(this, 4), dp(this, 4), dp(this, 4), dp(this, 6));
            row.addView(chip, p);
        }
        scroll.addView(row);
        panel.addView(scroll);
    }

    private void auto() {
        if (base == null) return;
        Bitmap small = Bitmap.createScaledBitmap(base, 32, 32, true);
        float sum = 0;
        for (int x = 0; x < 32; x++) {
            for (int y = 0; y < 32; y++) {
                int c = small.getPixel(x, y);
                sum += 0.3f * Color.red(c) + 0.59f * Color.green(c) + 0.11f * Color.blue(c);
            }
        }
        brightness = Math.max(-40, Math.min(40, (118 - sum / 1024) * 0.5f));
        contrast = 1.1f;
        saturation = 1.15f;
        showTab(0);
    }

    private void geometry(int n) {
        if (base == null) return;
        int w = base.getWidth(), h = base.getHeight();
        if (n == 5) {
            base = original;
        } else if (n < 2) {
            Matrix matrix = new Matrix();
            if (n == 0) matrix.postRotate(90);
            else matrix.postScale(-1, 1);
            base = Bitmap.createBitmap(base, 0, 0, w, h, matrix, true);
        } else {
            float ratio = n == 2 ? 1f : n == 3 ? 4f / 3 : 16f / 9;
            float target = w >= h ? ratio : 1 / ratio;
            int cw = Math.max(1, Math.min(w, Math.round(h * target)));
            int ch = Math.max(1, Math.min(h, Math.round(w / target)));
            base = Bitmap.createBitmap(base, (w - cw) / 2, (h - ch) / 2, cw, ch);
        }
    }

    private ColorMatrix colors() {
        ColorMatrix result = new ColorMatrix();
        float boost = filter == 1 || filter == 4 ? 0 : filter == 5 ? 1.4f : 1;
        result.setSaturation(saturation * boost);
        ColorMatrix tint = new ColorMatrix();
        if (filter == 2) tint.setScale(1.12f, 1.02f, 0.88f, 1);
        if (filter == 3) tint.setScale(0.9f, 1f, 1.14f, 1);
        if (filter == 4) tint.setScale(1.1f, 0.95f, 0.75f, 1);
        result.postConcat(tint);
        float shift = brightness + 128 * (1 - contrast);
        result.postConcat(new ColorMatrix(new float[]{
                contrast, 0, 0, 0, shift,
                0, contrast, 0, 0, shift,
                0, 0, contrast, 0, shift,
                0, 0, 0, 1, 0}));
        return result;
    }

    private void refresh() {
        if (base == null) return;
        image.setImageBitmap(base);
        image.setColorFilter(new ColorMatrixColorFilter(colors()));
    }

    private void saveCopy() {
        if (base == null) return;
        done.setEnabled(false);
        Bitmap source = base;
        ColorMatrixColorFilter colorFilter = new ColorMatrixColorFilter(colors());
        IO.execute(() -> {
            boolean ok = false;
            try {
                Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
                Paint paint = new Paint();
                paint.setColorFilter(colorFilter);
                new Canvas(result).drawBitmap(source, 0, 0, paint);
                save(this, "Gallery", "edit_" + System.currentTimeMillis() + ".jpg", "image/jpeg", out -> {
                    if (!result.compress(Bitmap.CompressFormat.JPEG, 95, out)) throw new IOException("compress");
                });
                ok = true;
            } catch (Exception | OutOfMemoryError ignored) { }
            boolean saved = ok;
            UI.post(() -> {
                Toast.makeText(getApplicationContext(), saved ? "Копия сохранена" : "Не получилось сохранить",
                        Toast.LENGTH_SHORT).show();
                if (saved) finish();
                else done.setEnabled(true);
            });
        });
    }
}
