package com.mygallery.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.media.ExifInterface;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import static com.mygallery.app.Library.*;

public class ViewerActivity extends Activity {
    private List<Media> list;
    private int index;
    private ImageView image, heart;
    private TextView title;
    private View header, bar;
    private LinearLayout strip;
    private final ImageView[] slots = new ImageView[15];
    private boolean playing;
    private final Runnable slide = new Runnable() {
        @Override public void run() {
            show((index + 1) % list.size());
            UI.postDelayed(this, 3000);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        list = viewing;
        if (list.isEmpty()) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        FrameLayout top = new FrameLayout(this);
        title = text(this, "", 14, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        TextView back = text(this, "‹", 34, BLUE);
        back.setPadding(dp(this, 18), 0, dp(this, 18), 0);
        back.setOnClickListener(v -> finish());
        top.addView(title, new FrameLayout.LayoutParams(-1, -1));
        top.addView(back, new FrameLayout.LayoutParams(-2, -1, Gravity.START));
        LinearLayout right = new LinearLayout(this);
        TextView edit = text(this, "Изменить", 16, BLUE);
        edit.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class).setData(list.get(index).uri)));
        TextView more = text(this, "⋯", 28, BLUE);
        more.setPadding(dp(this, 14), 0, dp(this, 14), 0);
        more.setOnClickListener(this::menu);
        right.addView(edit, new LinearLayout.LayoutParams(-2, -1));
        right.addView(more, new LinearLayout.LayoutParams(-2, -1));
        top.addView(right, new FrameLayout.LayoutParams(-2, -1, Gravity.END));
        header = top;
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(this, 56)));

        FrameLayout stage = new FrameLayout(this);
        image = new ImageView(this);
        stage.addView(image);
        root.addView(stage, new LinearLayout.LayoutParams(-1, 0, 1));

        strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        for (int n = 0; n < slots.length; n++) {
            final int offset = n - slots.length / 2;
            ImageView slot = new ImageView(this);
            slot.setScaleType(ImageView.ScaleType.CENTER_CROP);
            slot.setOnClickListener(v -> show(index + offset));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(this, 28), -1);
            int gap = dp(this, offset == 0 ? 8 : 1);
            p.setMargins(gap, 0, gap, 0);
            strip.addView(slot, p);
            slots[n] = slot;
        }
        root.addView(strip, new LinearLayout.LayoutParams(-1, dp(this, 40)));

        LinearLayout buttons = new LinearLayout(this);
        button(buttons, R.drawable.ic_share, "Поделиться", v -> {
            List<Media> one = new ArrayList<>();
            one.add(list.get(index));
            share(this, one);
        });
        heart = button(buttons, R.drawable.ic_heart, "В избранное", v -> {
            List<Media> one = new ArrayList<>();
            one.add(list.get(index));
            ask(this, MediaStore.createFavoriteRequest(getContentResolver(), uris(one), !list.get(index).favorite), 1);
        });
        button(buttons, R.drawable.ic_info, "Информация", v -> info());
        button(buttons, R.drawable.ic_trash, "Удалить", v -> {
            List<Media> one = new ArrayList<>();
            one.add(list.get(index));
            ask(this, MediaStore.createTrashRequest(getContentResolver(), uris(one), true), 2);
        });
        bar = buttons;
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(this, 60)));
        setContentView(root);

        ScaleGestureDetector pinch = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoom(image.getScaleX() * d.getScaleFactor());
                return true;
            }
        });
        GestureDetector gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                move(-dx, -dy);
                return true;
            }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (!pinch.isInProgress() && image.getScaleX() == 1 && Math.abs(vx) > Math.abs(vy)) {
                    show(index + (vx < 0 ? 1 : -1));
                }
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                zoom(image.getScaleX() > 1 ? 1 : 2.5f);
                return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (playing) play(false);
                else chrome(header.getVisibility() != View.VISIBLE);
                return true;
            }
        });
        stage.setOnTouchListener((v, e) -> {
            pinch.onTouchEvent(e);
            gestures.onTouchEvent(e);
            return true;
        });
        show(getIntent().getIntExtra("index", 0));
    }

    private ImageView button(LinearLayout parent, int icon, String label, View.OnClickListener click) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setColorFilter(BLUE);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setContentDescription(label);
        b.setOnClickListener(click);
        parent.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
        return b;
    }

    private void show(int i) {
        if (i < 0 || i >= list.size()) return;
        index = i;
        Media m = list.get(i);
        title.setText(date(m.date, "d MMMM yyyy\nHH:mm"));
        heart.setImageResource(m.favorite ? R.drawable.ic_heart_full : R.drawable.ic_heart);
        for (int n = 0; n < slots.length; n++) {
            int at = i + n - slots.length / 2;
            boolean exists = at >= 0 && at < list.size();
            slots[n].setVisibility(exists ? View.VISIBLE : View.INVISIBLE);
            if (exists) thumb(slots[n], list.get(at), 128);
        }
        zoom(1);
        image.setImageDrawable(null);
        image.setTag(m.uri);
        IO.execute(() -> {
            try {
                Bitmap bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), m.uri),
                        (decoder, info, source) -> {
                            int max = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                            decoder.setTargetSampleSize(Math.max(1, (int) Math.ceil(max / 3000.0)));
                        });
                UI.post(() -> { if (m.uri.equals(image.getTag())) image.setImageBitmap(bitmap); });
            } catch (Exception ignored) { }
        });
    }

    private void chrome(boolean visible) {
        int state = visible ? View.VISIBLE : View.INVISIBLE;
        header.setVisibility(state);
        strip.setVisibility(state);
        bar.setVisibility(state);
    }

    private void play(boolean on) {
        playing = on;
        UI.removeCallbacks(slide);
        chrome(!on);
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            UI.postDelayed(slide, 3000);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (playing) play(false);
    }

    private void menu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        String[] names = {"Копировать", "Дублировать", "Копия в альбом…", "Слайд-шоу", "Сделать обоями"};
        for (int i = 0; i < names.length; i++) menu.getMenu().add(0, i, i, names[i]);
        menu.setOnMenuItemClickListener(item -> {
            Media m = list.get(index);
            int id = item.getItemId();
            if (id == 0) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newUri(getContentResolver(), m.name, m.uri));
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
            } else if (id == 1) {
                copy(getApplicationContext(), m, "Gallery");
            } else if (id == 2) {
                EditText input = new EditText(this);
                input.setHint("Название альбома");
                new AlertDialog.Builder(this).setTitle("Копия в альбом").setView(input)
                        .setPositiveButton("Добавить", (d, w) -> {
                            String name = input.getText().toString().replaceAll("[\\\\/:*?\"<>|.]", "").trim();
                            if (!name.isEmpty()) copy(getApplicationContext(), m, name);
                        })
                        .setNegativeButton("Отмена", null).show();
            } else if (id == 3) {
                play(true);
            } else {
                Intent i = new Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(m.uri, "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Использовать как"));
            }
            return true;
        });
        menu.show();
    }

    private void zoom(float z) {
        z = Math.max(1, Math.min(z, 6));
        image.setScaleX(z);
        image.setScaleY(z);
        move(0, 0);
    }

    private void move(float dx, float dy) {
        float maxX = image.getWidth() * (image.getScaleX() - 1) / 2;
        float maxY = image.getHeight() * (image.getScaleY() - 1) / 2;
        image.setTranslationX(Math.max(-maxX, Math.min(maxX, image.getTranslationX() + dx)));
        image.setTranslationY(Math.max(-maxY, Math.min(maxY, image.getTranslationY() + dy)));
    }

    private void info() {
        Media m = list.get(index);
        StringBuilder s = new StringBuilder();
        s.append(date(m.date, "EEEE, d MMMM yyyy, HH:mm")).append('\n').append(m.name).append("\n\n");
        s.append(m.width).append(" × ").append(m.height).append(" • ");
        s.append(String.format(Locale.US, "%.1f МБ", m.size / 1048576.0)).append("\nАльбом: ").append(m.album);
        try (InputStream in = getContentResolver().openInputStream(m.uri)) {
            ExifInterface exif = new ExifInterface(in);
            String model = exif.getAttribute(ExifInterface.TAG_MODEL);
            if (model != null) s.append("\n\nКамера: ").append(model);
            String iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
            if (iso != null) s.append("\nISO ").append(iso);
            double mm = exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0);
            double f = exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0);
            double sec = exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0);
            if (mm > 0) s.append(String.format(Locale.US, "\n%.0f мм", mm));
            if (f > 0) s.append(String.format(Locale.US, "\nƒ/%.1f", f));
            if (sec > 0) s.append(String.format(Locale.US, "\nВыдержка %.4f с", sec));
        } catch (Exception ignored) { }
        new AlertDialog.Builder(this).setTitle("Информация").setMessage(s).setPositiveButton("OK", null).show();
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        if (result != RESULT_OK) return;
        if (code == 1) {
            Media m = list.get(index);
            m.favorite = !m.favorite;
            heart.setImageResource(m.favorite ? R.drawable.ic_heart_full : R.drawable.ic_heart);
        } else {
            list.remove(index);
            if (list.isEmpty()) finish();
            else show(Math.min(index, list.size() - 1));
        }
    }
}
