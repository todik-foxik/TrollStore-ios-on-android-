package com.mygallery.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Insets;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.ExifInterface;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import static com.mygallery.app.Library.*;

public class ViewerActivity extends Activity {
    private static final int NONE = 0, PAGE = 1, DOWN = 2, UP = 3;

    private final ImageView[] pages = new ImageView[3];
    private final ImageView[] slots = new ImageView[15];
    private final LruCache<Long, Bitmap> cache = new LruCache<>(4);
    private final Runnable slide = new Runnable() {
        @Override public void run() {
            if (index + 1 < list.size()) turn(1);
            else show(0);
            UI.postDelayed(this, 3000);
        }
    };
    private List<Media> list;
    private int index, startIndex, mode, bottomInset;
    private float dragX, dragY, flingX, flingY;
    private boolean playing, busy, closing, chromeShown = true;
    private FrameLayout root, stage, overlay;
    private Backdrop backdrop;
    private Glass top, bottom;
    private View shade;
    private ImageView heart;
    private TextView title;
    private Rect from;
    private ScaleGestureDetector pinch;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        list = viewing;
        if (list.isEmpty()) {
            finish();
            return;
        }
        Motion.edgeToEdge(this);
        startIndex = Math.max(0, Math.min(getIntent().getIntExtra("index", 0), list.size() - 1));
        from = getIntent().getParcelableExtra("from");

        root = new FrameLayout(this);
        backdrop = new Backdrop(this);
        shade = new View(this);
        shade.setBackgroundColor(Color.BLACK);
        stage = new FrameLayout(this);
        for (int i = 0; i < 3; i++) {
            pages[i] = new ImageView(this);
            stage.addView(pages[i]);
        }
        stage.addOnLayoutChangeListener((v, l, t, r, b, oldL, oldT, oldR, oldB) -> {
            if (r - l != oldR - oldL) place(0);
        });
        backdrop.addView(shade);
        backdrop.addView(stage);
        root.addView(backdrop);
        buildTop();
        buildBottom();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            Insets system = insets.getInsets(WindowInsets.Type.systemBars());
            bottomInset = system.bottom;
            top.getLayoutParams().height = system.top + dp(this, 52);
            bottom.getLayoutParams().height = system.bottom + dp(this, 98);
            top.requestLayout();
            bottom.requestLayout();
            return insets;
        });
        setContentView(root);
        gestures();
        show(startIndex);
        if (from != null && state == null) enter();
    }

    private void buildTop() {
        top = new Glass(this, backdrop, 0xB8161618);
        FrameLayout header = new FrameLayout(this);
        title = text(this, "", 14, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        header.addView(title, new FrameLayout.LayoutParams(-1, -1));
        header.addView(icon(R.drawable.ic_back, v -> close()),
                new FrameLayout.LayoutParams(dp(this, 52), -1, Gravity.START));
        LinearLayout right = new LinearLayout(this);
        TextView edit = text(this, "Изменить", 16, BLUE);
        edit.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class).setData(list.get(index).uri)));
        Motion.press(edit);
        right.addView(edit, new LinearLayout.LayoutParams(-2, -1));
        right.addView(icon(R.drawable.ic_more, v -> menu()), new LinearLayout.LayoutParams(dp(this, 52), -1));
        header.addView(right, new FrameLayout.LayoutParams(-2, -1, Gravity.END));
        top.addView(header, new FrameLayout.LayoutParams(-1, dp(this, 52), Gravity.BOTTOM));
        root.addView(top, new FrameLayout.LayoutParams(-1, dp(this, 52), Gravity.TOP));
    }

    private void buildBottom() {
        bottom = new Glass(this, backdrop, 0xB8161618);
        LinearLayout column = column();
        LinearLayout strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        strip.setPadding(0, dp(this, 6), 0, dp(this, 2));
        for (int n = 0; n < slots.length; n++) {
            final int offset = n - slots.length / 2;
            ImageView slot = new ImageView(this);
            slot.setScaleType(ImageView.ScaleType.CENTER_CROP);
            slot.setOnClickListener(v -> show(index + offset));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(this, 28), -1);
            int gap = dp(this, offset == 0 ? 8 : 1);
            p.setMargins(gap, 0, gap, 0);
            strip.addView(slot, p);
            slots[n] = slot;
        }
        column.addView(strip, new LinearLayout.LayoutParams(-1, dp(this, 46)));
        LinearLayout buttons = new LinearLayout(this);
        heart = icon(R.drawable.ic_heart, v -> favorite());
        ImageView[] items = {
                icon(R.drawable.ic_share, v -> share(this, Collections.singletonList(list.get(index)))),
                heart,
                icon(R.drawable.ic_info, v -> info()),
                icon(R.drawable.ic_trash, v -> ask(this, MediaStore.createTrashRequest(getContentResolver(),
                        Collections.singletonList(list.get(index).uri), true), 2))};
        for (ImageView item : items) buttons.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
        column.addView(buttons, new LinearLayout.LayoutParams(-1, dp(this, 52)));
        bottom.addView(column, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        root.addView(bottom, new FrameLayout.LayoutParams(-1, dp(this, 98), Gravity.BOTTOM));
    }

    private ImageView icon(int resource, View.OnClickListener click) {
        ImageView view = new ImageView(this);
        view.setImageResource(resource);
        view.setColorFilter(BLUE);
        view.setScaleType(ImageView.ScaleType.CENTER);
        view.setOnClickListener(click);
        Motion.press(view);
        return view;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void gestures() {
        pinch = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (mode != NONE) return true;
                float z = Math.max(1f, Math.min(pages[1].getScaleX() * d.getScaleFactor(), 6f));
                pages[1].setScaleX(z);
                pages[1].setScaleY(z);
                move(0, 0);
                return true;
            }
        });
        GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) {
                return true;
            }
            @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                if (pinch.isInProgress() || a == null || playing) return true;
                if (mode == NONE && pages[1].getScaleX() > 1) {
                    move(-dx, -dy);
                    return true;
                }
                dragX = b.getX() - a.getX();
                dragY = b.getY() - a.getY();
                if (mode == NONE) mode = Math.abs(dragX) > Math.abs(dragY) ? PAGE : dragY > 0 ? DOWN : UP;
                drag();
                return true;
            }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                flingX = vx;
                flingY = vy;
                return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (playing) play(false);
                else chrome(!chromeShown);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                float z = pages[1].getScaleX() > 1 ? 1f : 2.5f;
                pages[1].animate().scaleX(z).scaleY(z).translationX(0).translationY(0).setDuration(280)
                        .setInterpolator(new DecelerateInterpolator(2));
                return true;
            }
        });
        stage.setOnTouchListener((v, e) -> {
            if (busy) return true;
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_POINTER_DOWN && mode != NONE) {
                mode = NONE;
                settle();
            }
            pinch.onTouchEvent(e);
            detector.onTouchEvent(e);
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) release();
            return true;
        });
    }

    private void drag() {
        if (mode == PAGE) {
            boolean edge = (dragX > 0 && index == 0) || (dragX < 0 && index == list.size() - 1);
            place(edge ? dragX * 0.3f : dragX);
        } else if (mode == DOWN) {
            float progress = Math.max(0f, Math.min(1f, dragY / stage.getHeight()));
            pages[1].setTranslationX(dragX);
            pages[1].setTranslationY(dragY);
            pages[1].setScaleX(1 - progress * 0.5f);
            pages[1].setScaleY(1 - progress * 0.5f);
            float alpha = Math.max(0f, 1 - progress * 2);
            shade.setAlpha(alpha);
            if (chromeShown) {
                top.setAlpha(alpha);
                bottom.setAlpha(alpha);
            }
        }
    }

    private void release() {
        float speed = dp(this, 500);
        if (mode == PAGE) {
            int step = dragX < -stage.getWidth() / 4f || flingX < -speed ? 1
                    : dragX > stage.getWidth() / 4f || flingX > speed ? -1 : 0;
            if (step != 0 && index + step >= 0 && index + step < list.size()) turn(step);
            else settle();
        } else if (mode == DOWN) {
            if (dragY > dp(this, 120) || flingY > speed) close();
            else settle();
        } else if (mode == UP && dragY < -dp(this, 60)) {
            info();
        }
        mode = NONE;
        flingX = flingY = 0;
    }

    private float pageWidth() {
        return stage.getWidth() + dp(this, 16);
    }

    private void place(float offset) {
        for (int i = 0; i < 3; i++) pages[i].setTranslationX((i - 1) * pageWidth() + offset);
    }

    private void settle() {
        for (int i = 0; i < 3; i++) {
            pages[i].animate().translationX((i - 1) * pageWidth()).translationY(0).scaleX(1).scaleY(1)
                    .setDuration(250).setInterpolator(new DecelerateInterpolator(2));
        }
        shade.animate().alpha(1).setDuration(250);
        if (chromeShown) {
            top.animate().alpha(1).setDuration(250);
            bottom.animate().alpha(1).setDuration(250);
        }
    }

    private void turn(int direction) {
        busy = true;
        for (int i = 0; i < 3; i++) {
            pages[i].animate().translationX((i - 1 - direction) * pageWidth()).setDuration(250)
                    .setInterpolator(new DecelerateInterpolator(1.5f));
        }
        UI.postDelayed(() -> {
            if (closing) return;
            busy = false;
            show(index + direction);
        }, 260);
    }

    private void show(int i) {
        if (i < 0 || i >= list.size()) return;
        index = i;
        Media m = list.get(i);
        title.setText(date(m.date, "d MMMM yyyy\nHH:mm"));
        heart.setImageResource(m.favorite ? R.drawable.ic_heart_full : R.drawable.ic_heart);
        for (int n = 0; n < 3; n++) {
            ImageView page = pages[n];
            page.animate().cancel();
            page.setScaleX(1);
            page.setScaleY(1);
            page.setTranslationY(0);
            page.setAlpha(1f);
            fill(page, i + n - 1);
        }
        place(0);
        for (int n = 0; n < slots.length; n++) {
            int at = i + n - slots.length / 2;
            boolean exists = at >= 0 && at < list.size();
            slots[n].setVisibility(exists ? View.VISIBLE : View.INVISIBLE);
            if (exists) thumb(slots[n], list.get(at), 128);
        }
        top.invalidate();
        bottom.invalidate();
    }

    private void fill(ImageView view, int i) {
        if (i < 0 || i >= list.size()) {
            view.setTag(null);
            view.setImageDrawable(null);
            return;
        }
        Media m = list.get(i);
        Bitmap ready = cache.get(m.id);
        if (ready != null) {
            view.setTag(m.uri);
            view.setImageBitmap(ready);
            return;
        }
        thumb(view, m, 384);
        view.setTag(m.uri);
        IO.execute(() -> {
            try {
                Bitmap bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), m.uri),
                        (decoder, info, source) -> {
                            int max = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                            decoder.setTargetSampleSize(Math.max(1, (int) Math.ceil(max / 2560.0)));
                        });
                UI.post(() -> {
                    cache.put(m.id, bitmap);
                    if (m.uri.equals(view.getTag())) view.setImageBitmap(bitmap);
                });
            } catch (Exception ignored) { }
        });
    }

    private int[] center() {
        int[] at = new int[2];
        stage.getLocationOnScreen(at);
        at[0] += stage.getWidth() / 2;
        at[1] += stage.getHeight() / 2;
        return at;
    }

    private void enter() {
        shade.setAlpha(0);
        top.setAlpha(0);
        bottom.setAlpha(0);
        stage.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                stage.getViewTreeObserver().removeOnPreDrawListener(this);
                int[] at = center();
                ImageView page = pages[1];
                float scale = from.width() / (float) stage.getWidth();
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setTranslationX(from.exactCenterX() - at[0]);
                page.setTranslationY(from.exactCenterY() - at[1]);
                page.animate().scaleX(1).scaleY(1).translationX(0).translationY(0).setDuration(320)
                        .setInterpolator(new DecelerateInterpolator(2));
                shade.animate().alpha(1).setDuration(250);
                top.animate().alpha(1).setDuration(250);
                bottom.animate().alpha(1).setDuration(250);
                return true;
            }
        });
    }

    private void close() {
        if (closing) return;
        closing = true;
        busy = true;
        UI.removeCallbacks(slide);
        pages[0].setVisibility(View.INVISIBLE);
        pages[2].setVisibility(View.INVISIBLE);
        boolean home = from != null && index == startIndex;
        int[] at = center();
        float scale = home ? from.width() / (float) stage.getWidth() : 0.7f;
        float x = home ? from.exactCenterX() - at[0] : 0f;
        float y = home ? from.exactCenterY() - at[1] : stage.getHeight() / 4f;
        pages[1].animate().scaleX(scale).scaleY(scale).translationX(x).translationY(y).alpha(home ? 1f : 0f)
                .setDuration(260).setInterpolator(new DecelerateInterpolator(1.5f));
        shade.animate().alpha(0).setDuration(260);
        top.animate().alpha(0).setDuration(150);
        bottom.animate().alpha(0).setDuration(150);
        UI.postDelayed(() -> {
            finish();
            overridePendingTransition(0, 0);
        }, 270);
    }

    @Override public void onBackPressed() {
        if (overlay != null) dismiss();
        else if (playing) play(false);
        else close();
    }

    private void chrome(boolean visible) {
        chromeShown = visible;
        if (visible) {
            top.setVisibility(View.VISIBLE);
            bottom.setVisibility(View.VISIBLE);
        }
        top.animate().alpha(visible ? 1f : 0f).setDuration(200);
        bottom.animate().alpha(visible ? 1f : 0f).setDuration(200);
        if (!visible) {
            UI.postDelayed(() -> {
                if (chromeShown) return;
                top.setVisibility(View.INVISIBLE);
                bottom.setVisibility(View.INVISIBLE);
            }, 210);
        }
    }

    private void play(boolean on) {
        playing = on;
        UI.removeCallbacks(slide);
        chrome(!on);
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            UI.postDelayed(slide, 3000);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (playing) play(false);
    }

    private void favorite() {
        Media m = list.get(index);
        ask(this, MediaStore.createFavoriteRequest(getContentResolver(),
                Collections.singletonList(m.uri), !m.favorite), 1);
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        if (result != RESULT_OK) return;
        if (code == 1) {
            Media m = list.get(index);
            m.favorite = !m.favorite;
            heart.setImageResource(m.favorite ? R.drawable.ic_heart_full : R.drawable.ic_heart);
            Motion.pop(heart);
        } else {
            busy = true;
            from = null;
            pages[1].animate().alpha(0).scaleX(0.6f).scaleY(0.6f).setDuration(220);
            UI.postDelayed(() -> {
                busy = false;
                list.remove(index);
                if (list.isEmpty()) finish();
                else show(Math.min(index, list.size() - 1));
            }, 230);
        }
    }

    private FrameLayout openOverlay() {
        if (overlay != null) root.removeView(overlay);
        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0x44000000);
        overlay.setOnClickListener(v -> dismiss());
        root.addView(overlay);
        return overlay;
    }

    private void dismiss() {
        if (overlay == null) return;
        View old = overlay;
        overlay = null;
        old.animate().alpha(0).setDuration(150);
        UI.postDelayed(() -> root.removeView(old), 160);
    }

    private void menu() {
        Media m = list.get(index);
        FrameLayout layer = openOverlay();
        Glass panel = new Glass(this, backdrop, 0xCC252527).round(14, false);
        LinearLayout column = column();
        row(column, "Копировать", R.drawable.ic_copy, () -> toClipboard(m));
        row(column, "Дублировать", R.drawable.ic_dup, () -> copy(getApplicationContext(), m, "Gallery"));
        row(column, "Копия в альбом…", R.drawable.ic_album_add, () -> chooseAlbum(m));
        row(column, "Слайд-шоу", R.drawable.ic_play, () -> play(true));
        row(column, "Сделать обоями", R.drawable.ic_wallpaper, () -> wallpaper(m));
        panel.addView(column, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(this, 250), -2, Gravity.TOP | Gravity.END);
        p.setMargins(0, top.getHeight(), dp(this, 10), 0);
        layer.addView(panel, p);
        panel.setClickable(true);
        panel.setPivotX(dp(this, 250));
        panel.setPivotY(0);
        panel.setScaleX(0.4f);
        panel.setScaleY(0.4f);
        panel.setAlpha(0);
        panel.animate().scaleX(1).scaleY(1).alpha(1).setDuration(260)
                .setInterpolator(new OvershootInterpolator(1.2f)).setUpdateListener(a -> panel.invalidate());
    }

    private void row(LinearLayout column, String name, int drawable, Runnable action) {
        TextView item = text(this, name, 16, Color.WHITE);
        item.setPadding(dp(this, 16), 0, dp(this, 16), 0);
        item.setCompoundDrawablesWithIntrinsicBounds(0, 0, drawable, 0);
        item.setOnClickListener(v -> {
            dismiss();
            action.run();
        });
        column.addView(item, new LinearLayout.LayoutParams(-1, dp(this, 46)));
        View line = new View(this);
        line.setBackgroundColor(0x26FFFFFF);
        column.addView(line, new LinearLayout.LayoutParams(-1, 1));
    }

    private void toClipboard(Media m) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newUri(getContentResolver(), m.name, m.uri));
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
    }

    private void chooseAlbum(Media m) {
        EditText input = new EditText(this);
        input.setHint("Название альбома");
        new AlertDialog.Builder(this).setTitle("Копия в альбом").setView(input)
                .setPositiveButton("Добавить", (d, w) -> {
                    String name = input.getText().toString().replaceAll("[\\\\/:*?\"<>|.]", "").trim();
                    if (!name.isEmpty()) copy(getApplicationContext(), m, name);
                })
                .setNegativeButton("Отмена", null).show();
    }

    private void wallpaper(Media m) {
        Intent intent = new Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(m.uri, "image/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Использовать как"));
    }

    private static void part(StringBuilder to, String value) {
        if (to.length() > 0) to.append("  |  ");
        to.append(value);
    }

    private void info() {
        Media m = list.get(index);
        String camera = "Нет данных о камере";
        StringBuilder values = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(m.uri)) {
            ExifInterface exif = new ExifInterface(in);
            String model = exif.getAttribute(ExifInterface.TAG_MODEL);
            if (model != null) camera = model;
            String iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
            if (iso != null) part(values, "ISO " + iso);
            double mm = exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0);
            double f = exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0);
            double sec = exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0);
            if (mm > 0) part(values, String.format(Locale.US, "%.0f мм", mm));
            if (f > 0) part(values, String.format(Locale.US, "ƒ/%.1f", f));
            if (sec > 0) part(values, sec < 1 ? String.format(Locale.US, "1/%.0f с", 1 / sec)
                    : String.format(Locale.US, "%.1f с", sec));
        } catch (Exception ignored) { }

        FrameLayout layer = openOverlay();
        Glass sheet = new Glass(this, backdrop, 0xD91C1C1E).round(16, true);
        LinearLayout column = column();
        column.setPadding(dp(this, 16), dp(this, 18), dp(this, 16), dp(this, 24) + bottomInset);
        column.addView(text(this, date(m.date, "EEEE • d MMMM yyyy • HH:mm"), 16, Color.WHITE));
        column.addView(text(this, m.name, 14, GRAY));
        LinearLayout card = column();
        card.setBackground(rounded(this, 0x22FFFFFF, 10));
        card.setPadding(dp(this, 12), dp(this, 10), dp(this, 12), dp(this, 10));
        TextView head = text(this, camera, 16, Color.WHITE);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(head);
        card.addView(text(this, String.format(Locale.US, "%.0f МП  •  %d × %d  •  %.1f МБ",
                m.width * (double) m.height / 1000000, m.width, m.height, m.size / 1048576.0), 14, GRAY));
        if (values.length() > 0) card.addView(text(this, values.toString(), 14, GRAY));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(this, 14), 0, dp(this, 12));
        column.addView(card, p);
        column.addView(text(this, "Альбом: " + m.album, 14, GRAY));
        sheet.addView(column, new FrameLayout.LayoutParams(-1, -2));
        layer.addView(sheet, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        sheet.setClickable(true);
        sheet.setTranslationY(dp(this, 400));
        sheet.animate().translationY(0).setDuration(320).setInterpolator(new DecelerateInterpolator(2))
                .setUpdateListener(a -> sheet.invalidate());
    }

    private void move(float dx, float dy) {
        ImageView page = pages[1];
        float maxX = page.getWidth() * (page.getScaleX() - 1) / 2;
        float maxY = page.getHeight() * (page.getScaleY() - 1) / 2;
        page.setTranslationX(Math.max(-maxX, Math.min(maxX, page.getTranslationX() + dx)));
        page.setTranslationY(Math.max(-maxY, Math.min(maxY, page.getTranslationY() + dy)));
    }
}
