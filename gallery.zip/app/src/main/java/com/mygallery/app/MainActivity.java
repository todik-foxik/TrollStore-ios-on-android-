package com.mygallery.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import static com.mygallery.app.Library.*;

public class MainActivity extends Activity {
    private static final String[] TITLES = {"Все фото", "Для вас", "Альбомы", "Поиск"};
    private static final int[] ICONS = {R.drawable.ic_grid, R.drawable.ic_star, R.drawable.ic_folder, R.drawable.ic_search};

    private final Set<Long> selected = new HashSet<>();
    private List<Media> all = new ArrayList<>(), trash = new ArrayList<>();
    private FrameLayout content;
    private LinearLayout tabs, bar;
    private TextView title, back, action;
    private GridView grid;
    private BaseAdapter adapter;
    private int tab;
    private boolean selecting, openTrash;
    private String openTitle, query = "", signature = "", gridKey = "";
    private Predicate<Media> openFilter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = column();
        FrameLayout header = new FrameLayout(this);
        title = text(this, "", 17, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        back = link("‹ Назад");
        action = link("Выбрать");
        header.addView(title, new FrameLayout.LayoutParams(-1, -1));
        header.addView(back, new FrameLayout.LayoutParams(-2, -1, Gravity.START));
        header.addView(action, new FrameLayout.LayoutParams(-2, -1, Gravity.END));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(this, 52)));
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        bar = new LinearLayout(this);
        TextView shareButton = link("Поделиться"), deleteButton = link("Удалить");
        bar.addView(shareButton, new LinearLayout.LayoutParams(0, -1, 1));
        bar.addView(deleteButton, new LinearLayout.LayoutParams(0, -1, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(this, 56)));

        tabs = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int n = i;
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            ImageView icon = new ImageView(this);
            icon.setImageResource(ICONS[i]);
            TextView label = text(this, TITLES[i], 11, GRAY);
            label.setGravity(Gravity.CENTER);
            item.addView(icon, new LinearLayout.LayoutParams(dp(this, 26), dp(this, 26)));
            item.addView(label);
            item.setOnClickListener(v -> { tab = n; openTitle = null; openTrash = false; render(); });
            tabs.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
        }
        root.addView(tabs, new LinearLayout.LayoutParams(-1, dp(this, 56)));
        setContentView(root);

        back.setOnClickListener(v -> onBackPressed());
        action.setOnClickListener(v -> {
            if (selecting) stopSelecting();
            else { selecting = true; updateChrome(); }
        });
        shareButton.setOnClickListener(v -> share(this, picked()));
        deleteButton.setOnClickListener(v -> {
            List<Media> list = picked();
            if (!list.isEmpty()) ask(this, MediaStore.createTrashRequest(getContentResolver(), uris(list), true), 1);
        });
        render();
        if (!allowed()) requestPermissions(new String[]{permission()}, 1);
    }

    @Override protected void onResume() {
        super.onResume();
        if (allowed()) reload();
    }

    @Override public void onRequestPermissionsResult(int code, String[] names, int[] results) {
        render();
        if (allowed()) reload();
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        if (result == RESULT_OK) { stopSelecting(); reload(); }
    }

    @Override public void onBackPressed() {
        if (selecting) stopSelecting();
        else if (openTitle != null) { openTitle = null; openTrash = false; render(); }
        else super.onBackPressed();
    }

    private String permission() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean allowed() { return checkSelfPermission(permission()) == PackageManager.PERMISSION_GRANTED; }

    private void reload() {
        IO.execute(() -> {
            try {
                List<Media> fresh = load(this, false), bin = load(this, true);
                StringBuilder s = new StringBuilder();
                for (Media m : fresh) s.append(m.id).append(m.favorite ? "f," : ",");
                s.append('|');
                for (Media m : bin) s.append(m.id).append(',');
                UI.post(() -> {
                    if (s.toString().equals(signature)) return;
                    signature = s.toString();
                    all = fresh;
                    trash = bin;
                    render();
                });
            } catch (Exception e) {
                UI.post(() -> Toast.makeText(this, "Не удалось прочитать фото", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void render() {
        int position = grid != null ? grid.getFirstVisiblePosition() : 0;
        String key = tab + ":" + openTitle;
        content.removeAllViews();
        grid = null;
        adapter = null;
        if (!allowed()) {
            View view = empty("Нет доступа к фото", "Нажмите, чтобы открыть настройки и разрешить доступ");
            view.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
            content.addView(view);
        } else if (openTitle != null) showGrid(content, openTrash ? trash : filter(openFilter));
        else if (tab == 0) showGrid(content, all);
        else if (tab == 1) showForYou();
        else if (tab == 2) showAlbums();
        else showSearch();
        if (grid != null && key.equals(gridKey)) grid.setSelection(position);
        gridKey = key;
        updateChrome();
    }

    private void updateChrome() {
        title.setText(selecting ? "Выбрано: " + selected.size() : openTitle != null ? openTitle : TITLES[tab]);
        back.setVisibility(openTitle != null && !selecting ? View.VISIBLE : View.GONE);
        action.setVisibility(selecting || (grid != null && !openTrash) ? View.VISIBLE : View.GONE);
        action.setText(selecting ? "Отмена" : "Выбрать");
        bar.setVisibility(selecting ? View.VISIBLE : View.GONE);
        tabs.setVisibility(selecting ? View.GONE : View.VISIBLE);
        for (int i = 0; i < 4; i++) {
            ViewGroup item = (ViewGroup) tabs.getChildAt(i);
            int color = i == tab ? BLUE : GRAY;
            ((ImageView) item.getChildAt(0)).setColorFilter(color);
            ((TextView) item.getChildAt(1)).setTextColor(color);
        }
    }

    private void stopSelecting() {
        selecting = false;
        selected.clear();
        if (adapter != null) adapter.notifyDataSetChanged();
        updateChrome();
    }

    private List<Media> filter(Predicate<Media> rule) {
        List<Media> out = new ArrayList<>();
        for (Media item : all) if (rule.test(item)) out.add(item);
        return out;
    }

    private List<Media> picked() { return filter(m -> selected.contains(m.id)); }

    private void showGrid(ViewGroup parent, List<Media> list) {
        if (list.isEmpty()) { parent.addView(empty("Нет фото", "")); return; }
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(this, 2));
        grid.setVerticalSpacing(dp(this, 2));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return list.size(); }
            @Override public Object getItem(int i) { return list.get(i); }
            @Override public long getItemId(int i) { return list.get(i).id; }
            @Override public View getView(int i, View old, ViewGroup group) {
                Cell cell = old != null ? (Cell) old : new Cell(MainActivity.this);
                Media m = list.get(i);
                thumb(cell.image, m, 384);
                cell.check.setVisibility(selected.contains(m.id) ? View.VISIBLE : View.GONE);
                return cell;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, id) -> {
            Media m = list.get(i);
            if (openTrash) {
                new AlertDialog.Builder(this).setTitle("Восстановить фото?")
                        .setPositiveButton("Восстановить", (d, w) -> {
                            List<Media> one = new ArrayList<>();
                            one.add(m);
                            ask(this, MediaStore.createTrashRequest(getContentResolver(), uris(one), false), 2);
                        })
                        .setNegativeButton("Отмена", null).show();
            } else if (selecting) {
                if (!selected.remove(m.id)) selected.add(m.id);
                adapter.notifyDataSetChanged();
                updateChrome();
            } else {
                viewing = new ArrayList<>(list);
                startActivity(new Intent(this, ViewerActivity.class).putExtra("index", i));
            }
        });
        grid.setOnItemLongClickListener((p, v, i, id) -> {
            if (openTrash) return false;
            selecting = true;
            selected.add(list.get(i).id);
            adapter.notifyDataSetChanged();
            updateChrome();
            return true;
        });
        parent.addView(grid);
    }

    private void showForYou() {
        if (all.isEmpty()) { content.addView(empty("Нет материалов", "Здесь появятся воспоминания из ваших фото")); return; }
        LinearLayout list = page();
        list.addView(heading("Воспоминания"));
        SimpleDateFormat day = formatter("dd.MM"), year = formatter("yyyy"), month = formatter("LLLL yyyy");
        String today = day.format(new Date()), thisYear = year.format(new Date());
        Predicate<Media> past = m -> day.format(new Date(m.date)).equals(today)
                && !year.format(new Date(m.date)).equals(thisYear);
        memory(list, "В этот день", filter(past), past);
        Map<String, List<Media>> months = new LinkedHashMap<>();
        for (Media item : all) months.computeIfAbsent(month.format(new Date(item.date)), k -> new ArrayList<>()).add(item);
        int count = 0;
        for (Map.Entry<String, List<Media>> entry : months.entrySet()) {
            String name = entry.getKey();
            memory(list, name.substring(0, 1).toUpperCase() + name.substring(1), entry.getValue(),
                    m -> month.format(new Date(m.date)).equals(name));
            if (++count == 12) break;
        }
    }

    private void memory(LinearLayout list, String name, List<Media> items, Predicate<Media> rule) {
        if (items.isEmpty()) return;
        FrameLayout card = new FrameLayout(this);
        card.setBackground(rounded(this, CARD, 14));
        card.setClipToOutline(true);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumb(image, items.get(0), 720);
        card.addView(image);
        TextView caption = text(this, name + "\n" + items.size() + " фото", 19, Color.WHITE);
        caption.setTypeface(Typeface.DEFAULT_BOLD);
        caption.setShadowLayer(8, 0, 2, Color.BLACK);
        caption.setPadding(dp(this, 14), 0, dp(this, 14), dp(this, 12));
        card.addView(caption, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        card.setOnClickListener(v -> open(name, rule, false));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(this, 240));
        params.setMargins(dp(this, 6), 0, dp(this, 6), dp(this, 14));
        list.addView(card, params);
    }

    private void showAlbums() {
        LinearLayout list = page();
        list.addView(heading("Мои альбомы"));
        List<View> cards = new ArrayList<>();
        cards.add(album("Недавние", m -> true));
        cards.add(album("Избранное", m -> m.favorite));
        Set<String> names = new TreeSet<>();
        for (Media item : all) names.add(item.album);
        for (String name : names) cards.add(album(name, m -> m.album.equals(name)));
        for (int i = 0; i < cards.size(); i += 2) {
            LinearLayout row = new LinearLayout(this);
            for (int j = i; j < i + 2; j++) {
                View child = j < cards.size() ? cards.get(j) : new Space(this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
                params.setMargins(dp(this, 6), 0, dp(this, 6), dp(this, 16));
                row.addView(child, params);
            }
            list.addView(row);
        }
        list.addView(heading("Служебные"));
        TextView deleted = link("Недавно удалённые (" + trash.size() + ")  ›");
        deleted.setGravity(Gravity.CENTER_VERTICAL);
        deleted.setOnClickListener(v -> open("Недавно удалённые", null, true));
        list.addView(deleted, new LinearLayout.LayoutParams(-1, dp(this, 52)));
    }

    private View album(String name, Predicate<Media> rule) {
        List<Media> items = filter(rule);
        LinearLayout box = column();
        Cell cell = new Cell(this);
        cell.setBackground(rounded(this, CARD, 8));
        cell.setClipToOutline(true);
        if (!items.isEmpty()) thumb(cell.image, items.get(0), 384);
        box.addView(cell);
        box.addView(text(this, name, 15, Color.WHITE));
        box.addView(text(this, String.valueOf(items.size()), 14, GRAY));
        box.setOnClickListener(v -> open(name, rule, false));
        return box;
    }

    private void open(String name, Predicate<Media> rule, boolean isTrash) {
        openTitle = name;
        openFilter = rule;
        openTrash = isTrash;
        render();
    }

    private void showSearch() {
        LinearLayout box = column();
        EditText input = new EditText(this);
        input.setHint("Название, альбом, месяц, год…");
        input.setSingleLine(true);
        input.setBackground(rounded(this, CARD, 10));
        input.setPadding(dp(this, 12), dp(this, 10), dp(this, 12), dp(this, 10));
        input.setText(query);
        FrameLayout results = new FrameLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(this, 12), 0, dp(this, 12), dp(this, 10));
        box.addView(input, params);
        box.addView(results, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(box);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                query = s.toString();
                search(results);
                updateChrome();
            }
        });
        search(results);
    }

    private void search(FrameLayout results) {
        results.removeAllViews();
        grid = null;
        adapter = null;
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) { results.addView(empty("Поиск", "Введите название файла, альбом, месяц или год")); return; }
        SimpleDateFormat words = formatter("LLLL yyyy d MMMM");
        showGrid(results, filter(m -> (m.name + " " + m.album + " " + words.format(new Date(m.date)))
                .toLowerCase(Locale.ROOT).contains(q)));
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout page() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        list.setPadding(dp(this, 10), 0, dp(this, 10), dp(this, 10));
        scroll.addView(list);
        content.addView(scroll);
        return list;
    }

    private TextView link(String s) {
        TextView t = text(this, s, 17, BLUE);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(this, 16), 0, dp(this, 16), 0);
        return t;
    }

    private TextView heading(String s) {
        TextView t = text(this, s, 22, Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(this, 6), dp(this, 12), 0, dp(this, 12));
        return t;
    }

    private View empty(String head, String sub) {
        LinearLayout box = column();
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(this, 32), 0, dp(this, 32), 0);
        TextView top = text(this, head, 22, Color.WHITE);
        top.setTypeface(Typeface.DEFAULT_BOLD);
        top.setGravity(Gravity.CENTER);
        TextView bottom = text(this, sub, 15, GRAY);
        bottom.setGravity(Gravity.CENTER);
        box.addView(top);
        box.addView(bottom);
        return box;
    }

    static class Cell extends FrameLayout {
        final ImageView image;
        final TextView check;

        Cell(Context c) {
            super(c);
            image = new ImageView(c);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(CARD);
            addView(image, new LayoutParams(-1, -1));
            check = text(c, "✓", 14, Color.WHITE);
            check.setGravity(Gravity.CENTER);
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(BLUE);
            circle.setStroke(dp(c, 2), Color.WHITE);
            check.setBackground(circle);
            check.setVisibility(GONE);
            LayoutParams params = new LayoutParams(dp(c, 26), dp(c, 26), Gravity.END | Gravity.BOTTOM);
            params.setMargins(0, 0, dp(c, 6), dp(c, 6));
            addView(check, params);
        }

        @Override protected void onMeasure(int width, int height) { super.onMeasure(width, width); }
    }
}
